import type { Config } from "tailwindcss";

/**
 * نظام الألوان: "تقرير فحص" بارد وواضح بدلاً من لوحات التحكم الداكنة المعتادة.
 * paper: الخلفية | surface: البطاقات | ink: النص | muted: النص الثانوي | line: الحدود
 * accent: نيلي للعناصر التفاعلية | pass/warn/fail: ألوان حالات الفحص
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F2F5F9",
        surface: "#FFFFFF",
        ink: "#142034",
        muted: "#5B667A",
        line: "#DDE3EC",
        accent: { DEFAULT: "#3A36B8", soft: "#ECEBFA" },
        pass: { DEFAULT: "#17865A", soft: "#E3F4EC" },
        warn: { DEFAULT: "#B7791F", soft: "#FBF1DF" },
        fail: { DEFAULT: "#C2362F", soft: "#FBE7E5" },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      keyframes: {
        reveal: { from: { opacity: "0", transform: "translateY(10px)" }, to: { opacity: "1", transform: "none" } },
      },
      animation: { reveal: "reveal .6s cubic-bezier(.2,.7,.2,1) both" },
    },
  },
  plugins: [],
};
export default config;
