"use client";

import { useRef, useState } from "react";
import ScanForm from "@/components/ScanForm";
import ScanProgress from "@/components/ScanProgress";
import Overview, { type TabId } from "@/components/Overview";
import SecurityPanel from "@/components/panels/SecurityPanel";
import PerformancePanel from "@/components/panels/PerformancePanel";
import SeoPanel from "@/components/panels/SeoPanel";
import TechPanel from "@/components/panels/TechPanel";
import { scanWebsite } from "@/lib/api";
import type { ScanResult } from "@/lib/types";

const TABS: { id: TabId; label: string }[] = [
  { id: "security", label: "الأمان" },
  { id: "performance", label: "الأداء" },
  { id: "seo", label: "محركات البحث" },
  { id: "tech", label: "التقنيات" },
];

export default function HomePage() {
  const [result, setResult] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<TabId>("security");
  const abortRef = useRef<AbortController | null>(null);

  async function handleScan(url: string) {
    // إلغاء أي فحص سابق لم يكتمل
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await scanWebsite(url, controller.signal);
      setResult(data);
      setTab("security");
    } catch (e) {
      if ((e as Error).name !== "AbortError") setError((e as Error).message);
    } finally {
      if (abortRef.current === controller) setLoading(false);
    }
  }

  function openTab(id: TabId) {
    setTab(id);
    document.getElementById("report")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <main className="mx-auto max-w-6xl px-4 pb-24 pt-12 sm:pt-20">
      <header className="max-w-3xl">
        <h1 className="text-4xl font-bold leading-tight sm:text-5xl">افحص أي موقع في دقيقة</h1>
        <p className="mt-4 max-w-[60ch] text-lg text-muted">
          أمان الاتصال والترويسات، سرعة التحميل ومؤشرات Core Web Vitals، جاهزية الصفحة لمحركات البحث، والتقنيات التي بُني بها.
        </p>
      </header>

      <div className="mt-8 max-w-3xl">
        <ScanForm onScan={handleScan} loading={loading} />
        <p className="mt-3 text-xs text-muted">افحص المواقع التي تملكها أو لديك إذن بفحصها.</p>
      </div>

      {error && (
        <div role="alert" className="mt-8 max-w-3xl rounded-xl border border-fail/30 bg-fail-soft p-4 text-fail">
          {error}
        </div>
      )}

      {loading && <div className="max-w-3xl"><ScanProgress /></div>}

      {result && !loading && (
        <div className="mt-12 space-y-8 animate-reveal">
          <Overview result={result} onSelect={openTab} />

          <div id="report" className="scroll-mt-6">
            <nav role="tablist" aria-label="أقسام التقرير" className="flex gap-1 overflow-x-auto border-b border-line">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  role="tab"
                  aria-selected={tab === t.id}
                  onClick={() => setTab(t.id)}
                  className={`-mb-px whitespace-nowrap border-b-2 px-4 py-3 text-sm font-medium transition-colors ${
                    tab === t.id ? "border-accent text-accent" : "border-transparent text-muted hover:text-ink"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </nav>

            <div className="pt-8" role="tabpanel">
              {tab === "security" && <SecurityPanel section={result.security} />}
              {tab === "performance" && <PerformancePanel section={result.performance} />}
              {tab === "seo" && <SeoPanel section={result.seo} url={result.final_url} />}
              {tab === "tech" && <TechPanel items={result.tech_stack} />}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
