"use client";

import { useEffect, useState } from "react";
import { scoreTone } from "@/lib/format";

/**
 * "ختم الفحص": العنصر المميّز في التصميم.
 * 60 شَرطة حول دائرة تُضاء بالتتابع حتى تصل للدرجة — مثل عدّاد جهاز قياس.
 */
export default function ScoreSeal({ score }: { score: number }) {
  const [lit, setLit] = useState(false);
  useEffect(() => {
    const t = requestAnimationFrame(() => setLit(true));
    return () => cancelAnimationFrame(t);
  }, [score]);

  const tone = scoreTone(score);
  const TICKS = 60;
  const active = Math.round((score / 100) * TICKS);
  const size = 220;
  const c = size / 2;

  return (
    <div className="relative" style={{ width: size, height: size }} role="img" aria-label={`الدرجة الإجمالية ${score} من 100`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {Array.from({ length: TICKS }, (_, i) => {
          const isOn = i < active;
          const long = i % 5 === 0;
          return (
            <line
              key={i}
              x1={c}
              y1={10}
              x2={c}
              y2={long ? 30 : 24}
              transform={`rotate(${i * 6} ${c} ${c})`}
              stroke={isOn ? tone.hex : "#DDE3EC"}
              strokeWidth={long ? 3 : 2}
              strokeLinecap="round"
              style={{
                opacity: isOn && !lit ? 0 : 1,
                transition: "opacity .25s ease",
                transitionDelay: `${i * 14}ms`,
              }}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-6xl font-semibold leading-none tracking-tight">{score}</span>
        <span className={`mt-2 text-sm font-medium ${tone.text}`}>{tone.label}</span>
      </div>
    </div>
  );
}
