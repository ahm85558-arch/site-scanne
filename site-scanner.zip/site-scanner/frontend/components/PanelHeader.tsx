import ScoreRing from "./ScoreRing";

interface Props {
  title: string;
  summary: string;
  score?: number;
}

/** رأس كل قسم: العنوان وملخص بجملة واحدة والدرجة */
export default function PanelHeader({ title, summary, score }: Props) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <h2 className="text-2xl font-semibold">{title}</h2>
        <p className="mt-1 max-w-[60ch] text-sm text-muted">{summary}</p>
      </div>
      {score !== undefined && <ScoreRing score={score} />}
    </div>
  );
}
