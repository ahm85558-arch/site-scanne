"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { ScanResult, Status } from "@/lib/types";
import { formatMs, hostnameOf, scoreTone } from "@/lib/format";
import ScoreSeal from "./ScoreSeal";
import { STATUS_META } from "./status";

export type TabId = "security" | "performance" | "seo" | "tech";

interface Props {
  result: ScanResult;
  onSelect: (tab: TabId) => void;
}

/** ملخص التقرير: الختم + درجات الأقسام + توزيع نتائج الفحوصات */
export default function Overview({ result, onSelect }: Props) {
  const sections: { id: TabId; label: string; score: number }[] = [
    { id: "security", label: "الأمان", score: result.security.score },
    { id: "performance", label: "الأداء", score: result.performance.score },
    { id: "seo", label: "محركات البحث", score: result.seo.score },
  ];

  const allChecks = [...result.security.checks, ...result.performance.checks, ...result.seo.checks];
  const distribution = (["pass", "warn", "fail"] as Status[]).map((s) => ({
    status: s,
    name: STATUS_META[s].label,
    value: allChecks.filter((c) => c.status === s).length,
  }));

  return (
    <section className="panel grid gap-8 p-6 sm:p-8 lg:grid-cols-[auto_1fr_auto] lg:items-center">
      <div className="flex flex-col items-center gap-3">
        <ScoreSeal score={result.overall_score} />
        <p className="text-sm text-muted">الدرجة الإجمالية من 100</p>
      </div>

      <div className="min-w-0 space-y-5">
        <div>
          <h2 dir="ltr" className="truncate text-right text-3xl font-semibold">{hostnameOf(result.final_url)}</h2>
          <p className="mt-1 text-sm text-muted">
            فُحص {new Date(result.scanned_at).toLocaleString("ar-SA")} خلال {formatMs(result.duration_ms)}
          </p>
          {result.final_url !== result.url && (
            <p className="mt-1 text-xs text-muted">
              تم التحويل إلى <span dir="ltr" className="font-mono">{result.final_url}</span>
            </p>
          )}
        </div>

        {/* أشرطة درجات الأقسام — الضغط عليها يفتح القسم */}
        <ul className="space-y-3">
          {sections.map((s) => {
            const tone = scoreTone(s.score);
            return (
              <li key={s.id}>
                <button type="button" onClick={() => onSelect(s.id)} className="group w-full text-right">
                  <div className="mb-1.5 flex justify-between text-sm">
                    <span className="font-medium group-hover:text-accent">{s.label}</span>
                    <span className={`font-semibold ${tone.text}`}>{s.score}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-paper">
                    <div
                      className="h-full rounded-full transition-[width] duration-700"
                      style={{ width: `${s.score}%`, background: tone.hex }}
                    />
                  </div>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* توزيع الفحوصات (دائري) */}
      <div className="flex items-center gap-4 lg:flex-col">
        <div className="h-36 w-36" dir="ltr">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={distribution} dataKey="value" nameKey="name" innerRadius={44} outerRadius={64} paddingAngle={2} stroke="none">
                {distribution.map((d) => (
                  <Cell key={d.status} fill={STATUS_META[d.status].hex} />
                ))}
              </Pie>
              <Tooltip formatter={(v: number, n: string) => [`${v} فحص`, n]} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <ul className="space-y-1.5 text-sm">
          {distribution.map((d) => (
            <li key={d.status} className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: STATUS_META[d.status].hex }} />
              <span className="text-muted">{d.name}</span>
              <span className="font-semibold">{d.value}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
