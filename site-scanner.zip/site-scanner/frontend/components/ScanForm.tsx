"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";

interface Props {
  onScan: (url: string) => void;
  loading: boolean;
}

export default function ScanForm({ onScan, loading }: Props) {
  const [url, setUrl] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (url.trim() && !loading) onScan(url.trim());
      }}
      className="flex flex-col gap-3 sm:flex-row"
    >
      <label htmlFor="url" className="sr-only">رابط الموقع</label>
      <input
        id="url"
        dir="ltr"
        type="text"
        inputMode="url"
        autoComplete="url"
        spellCheck={false}
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="example.com"
        className="h-14 flex-1 rounded-xl border border-line bg-surface px-5 font-mono text-base text-ink placeholder:text-muted/60 focus:border-accent"
      />
      <button
        type="submit"
        disabled={loading || !url.trim()}
        className="flex h-14 items-center justify-center gap-2 rounded-xl bg-accent px-8 text-base font-semibold text-white transition-colors hover:bg-[#2E2A9A] disabled:cursor-not-allowed disabled:opacity-50"
      >
        {loading && <Loader2 className="h-5 w-5 animate-spin" />}
        {loading ? "جارٍ الفحص" : "افحص الموقع"}
      </button>
    </form>
  );
}
