"use client";

import { useMemo, useState } from "react";
import type { Check, Status } from "@/lib/types";
import { STATUS_META, StatusIcon } from "./status";

const ORDER: Status[] = ["fail", "warn", "pass", "info"];

/** قائمة الفحوصات مرتبة بالأخطر أولاً، مع تصفية حسب الحالة */
export default function ChecksList({ checks }: { checks: Check[] }) {
  const [filter, setFilter] = useState<Status | "all">("all");

  const sorted = useMemo(
    () => [...checks].sort((a, b) => ORDER.indexOf(a.status) - ORDER.indexOf(b.status)),
    [checks],
  );
  const visible = filter === "all" ? sorted : sorted.filter((c) => c.status === filter);
  const count = (s: Status) => checks.filter((c) => c.status === s).length;

  return (
    <div className="panel">
      <div className="flex flex-wrap items-center gap-2 border-b border-line p-4">
        <FilterButton active={filter === "all"} onClick={() => setFilter("all")}>
          الكل {checks.length}
        </FilterButton>
        {ORDER.filter((s) => count(s) > 0).map((s) => (
          <FilterButton key={s} active={filter === s} onClick={() => setFilter(s)}>
            {STATUS_META[s].label} {count(s)}
          </FilterButton>
        ))}
      </div>
      <ul className="divide-y divide-line">
        {visible.map((check) => (
          <li key={check.id} className="flex items-start gap-3 px-4 py-3.5">
            <StatusIcon status={check.status} className="mt-0.5 h-5 w-5" />
            <div className="min-w-0">
              <p className="font-medium">{check.title}</p>
              <p className="mt-0.5 text-sm text-muted">{check.message}</p>
              {Array.isArray(check.value) && check.value.length > 0 && (
                <ul className="mt-2 space-y-1">
                  {(check.value as string[]).slice(0, 5).map((v) => (
                    <li key={v} dir="ltr" className="code text-left">{v}</li>
                  ))}
                </ul>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function FilterButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-3 py-1 text-sm transition-colors ${
        active ? "bg-ink text-white" : "bg-paper text-muted hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}
