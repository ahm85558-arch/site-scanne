"use client";

import { useEffect, useState } from "react";
import { Check, Loader2 } from "lucide-react";

// مراحل الفحص تسلسلية فعلاً، لذا عرضها كقائمة مرتبة منطقي
const STEPS = [
  "الاتصال بالموقع وقراءة الصفحة",
  "فحص شهادة SSL والترويسات الأمنية",
  "تحليل SEO والبحث عن الروابط المعطلة",
  "قياس Core Web Vitals عبر Lighthouse",
  "اكتشاف التقنيات وإعداد التقرير",
];

export default function ScanProgress() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setCurrent((c) => Math.min(c + 1, STEPS.length - 1)), 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="panel mt-8 p-6" aria-live="polite">
      <ol className="space-y-3">
        {STEPS.map((step, i) => (
          <li key={step} className={`flex items-center gap-3 text-sm ${i > current ? "text-muted/60" : ""}`}>
            {i < current ? (
              <Check className="h-4 w-4 text-pass" />
            ) : i === current ? (
              <Loader2 className="h-4 w-4 animate-spin text-accent" />
            ) : (
              <span className="h-4 w-4 rounded-full border border-line" />
            )}
            {step}
          </li>
        ))}
      </ol>
      <p className="mt-5 text-xs text-muted">قياس Lighthouse يستغرق عادةً من 20 إلى 60 ثانية.</p>
    </div>
  );
}
