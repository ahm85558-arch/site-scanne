"use client";

import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { PerformanceData, Section, WebVitals } from "@/lib/types";
import { formatBytes, formatMs, rateValue } from "@/lib/format";
import ChecksList from "../ChecksList";
import PanelHeader from "../PanelHeader";
import { STATUS_META } from "../status";

// مؤشرات Lighthouse وعتباتها الرسمية من Google (جيد / ضعيف)
const VITALS: {
  key: "lcp_ms" | "cls" | "tbt_ms" | "fcp_ms" | "si_ms";
  label: string;
  hint: string;
  good: number;
  poor: number;
  format: (v: number) => string;
}[] = [
  { key: "lcp_ms", label: "LCP", hint: "ظهور أكبر عنصر", good: 2500, poor: 4000, format: formatMs },
  { key: "cls", label: "CLS", hint: "ثبات التخطيط", good: 0.1, poor: 0.25, format: (v) => v.toFixed(3) },
  { key: "tbt_ms", label: "TBT", hint: "زمن حجب التفاعل", good: 200, poor: 600, format: formatMs },
  { key: "fcp_ms", label: "FCP", hint: "أول محتوى مرئي", good: 1800, poor: 3000, format: formatMs },
  { key: "si_ms", label: "Speed Index", hint: "سرعة اكتمال العرض", good: 3400, poor: 5800, format: formatMs },
];

export default function PerformancePanel({ section }: { section: Section<PerformanceData> }) {
  const d = section.data;
  const resourceData = [
    { name: "JavaScript", bytes: d.resources.scripts.bytes, count: d.resources.scripts.count, color: "#3A36B8" },
    { name: "CSS", bytes: d.resources.stylesheets.bytes, count: d.resources.stylesheets.count, color: "#7C79D6" },
    { name: "الصور", bytes: d.resources.images.bytes, count: d.resources.images.count, color: "#17865A" },
    { name: "HTML", bytes: d.html_bytes, count: 1, color: "#5B667A" },
  ];

  return (
    <div className="space-y-6">
      <PanelHeader
        title="الأداء والسرعة"
        score={section.score}
        summary="قياسات من خادم الفحص، ومؤشرات Core Web Vitals من Lighthouse على جهاز جوال."
      />

      {/* أرقام سريعة */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="زمن أول بايت" value={formatMs(d.ttfb_ms)} />
        <Stat label="تحميل HTML" value={formatMs(d.total_ms)} />
        <Stat label="وزن الصفحة التقريبي" value={formatBytes(d.page_weight_bytes)} />
        <Stat label="البروتوكول" value={d.http_version} ltr />
      </div>

      {/* Core Web Vitals */}
      <div className="panel p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="font-semibold">Core Web Vitals</h3>
          {d.web_vitals?.lighthouse_score != null && (
            <span className="text-sm text-muted">
              درجة Lighthouse: <span className="font-semibold text-ink">{d.web_vitals.lighthouse_score}</span>
            </span>
          )}
        </div>
        {d.web_vitals ? (
          <>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {VITALS.map((v) => (
                <VitalTile key={v.key} def={v} value={d.web_vitals![v.key]} />
              ))}
            </div>
            <FieldData field={d.web_vitals.field} />
          </>
        ) : (
          <p className="mt-3 text-sm text-warn">{d.web_vitals_error ?? "لم تتوفر بيانات Lighthouse."}</p>
        )}
      </div>

      {/* حجم الموارد حسب النوع */}
      <div className="panel p-5">
        <h3 className="font-semibold">توزيع حجم الموارد</h3>
        <p className="mt-1 text-sm text-muted">
          قِسنا {d.resources.measured} مورداً، منها {d.resources.uncached} بدون تخزين مؤقت مناسب.
        </p>
        <div className="mt-4 h-56" dir="ltr">
          <ResponsiveContainer>
            <BarChart data={resourceData} layout="vertical" margin={{ left: 8, right: 24 }}>
              <XAxis type="number" tickFormatter={(v) => formatBytes(v)} tick={{ fontSize: 12, fill: "#5B667A" }} />
              <YAxis type="category" dataKey="name" width={84} tick={{ fontSize: 13, fill: "#142034" }} />
              <Tooltip
                cursor={{ fill: "#F2F5F9" }}
                formatter={(v: number, _n, item) => [`${formatBytes(v)} — ${item.payload.count} ملف`, "الحجم"]}
              />
              <Bar dataKey="bytes" radius={[0, 6, 6, 0]} barSize={22}>
                {resourceData.map((r) => (
                  <Cell key={r.name} fill={r.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <ChecksList checks={section.checks} />
    </div>
  );
}

function Stat({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="tile">
      <p className="text-sm text-muted">{label}</p>
      <p dir={ltr ? "ltr" : undefined} className={`mt-1 text-2xl font-semibold ${ltr ? "text-right" : ""}`}>{value}</p>
    </div>
  );
}

function VitalTile({ def, value }: { def: (typeof VITALS)[number]; value: number | null }) {
  if (value == null) {
    return (
      <div className="tile">
        <p className="font-semibold">{def.label}</p>
        <p className="mt-2 text-muted">—</p>
      </div>
    );
  }
  const status = rateValue(value, def.good, def.poor);
  const meta = STATUS_META[status];
  return (
    <div className={`rounded-lg border-t-4 p-4 ${meta.soft}`} style={{ borderTopColor: meta.hex }}>
      <p className="font-semibold">{def.label}</p>
      <p className="text-xs text-muted">{def.hint}</p>
      <p className={`mt-2 text-2xl font-semibold ${meta.text}`}>{def.format(value)}</p>
    </div>
  );
}

function FieldData({ field }: { field: WebVitals["field"] }) {
  if (!field) {
    return (
      <p className="mt-4 text-xs text-muted">
        لا تتوفر بيانات من مستخدمين حقيقيين (CrUX) لهذا الموقع — تظهر عادةً للمواقع ذات الزيارات المرتفعة.
      </p>
    );
  }
  return (
    <div className="mt-4 rounded-lg bg-accent-soft p-4 text-sm">
      <p className="font-medium text-accent">بيانات مستخدمين حقيقيين (آخر 28 يوماً)</p>
      <p dir="ltr" className="mt-1 flex flex-wrap justify-end gap-x-5 text-muted">
        <span>LCP <b className="text-ink">{formatMs(field.lcp_ms)}</b></span>
        <span>INP <b className="text-ink">{formatMs(field.inp_ms)}</b></span>
        <span>CLS <b className="text-ink">{field.cls?.toFixed(2) ?? "—"}</b></span>
      </p>
    </div>
  );
}
