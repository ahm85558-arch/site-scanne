import type { Section, SecurityData } from "@/lib/types";
import ChecksList from "../ChecksList";
import PanelHeader from "../PanelHeader";
import { StatusIcon, StatusPill } from "../status";

export default function SecurityPanel({ section }: { section: Section<SecurityData> }) {
  const { ssl, headers } = section.data;
  const fails = section.checks.filter((c) => c.status === "fail").length;

  return (
    <div className="space-y-6">
      <PanelHeader
        title="الأمان"
        score={section.score}
        summary={fails ? `${fails} مشكلة تحتاج معالجة عاجلة، مرتبة بالأخطر أولاً.` : "لا توجد مشكلات حرجة. راجع التحذيرات لتحسين الحماية."}
      />

      <div className="grid gap-4 lg:grid-cols-2">
        {/* بطاقة شهادة SSL */}
        <div className="panel p-5">
          <h3 className="font-semibold">شهادة SSL</h3>
          {!ssl ? (
            <p className="mt-3 text-sm text-fail">الموقع لا يستخدم HTTPS.</p>
          ) : !ssl.valid ? (
            <p className="mt-3 text-sm text-fail">{ssl.error}</p>
          ) : (
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <Info label="الجهة المُصدرة" value={ssl.issuer ?? "—"} />
              <Info label="النطاق" value={ssl.subject ?? "—"} ltr />
              <Info label="تنتهي في" value={ssl.expires_at ? new Date(ssl.expires_at).toLocaleDateString("ar-SA") : "—"} />
              <div>
                <dt className="text-muted">الأيام المتبقية</dt>
                <dd className="mt-1">
                  <StatusPill status={(ssl.days_left ?? 0) < 15 ? "warn" : "pass"}>{ssl.days_left} يوماً</StatusPill>
                </dd>
              </div>
              <Info label="بروتوكول TLS" value={ssl.tls_version ?? "—"} ltr />
            </dl>
          )}
        </div>

        {/* جدول الترويسات الأمنية */}
        <div className="panel p-5">
          <h3 className="font-semibold">الترويسات الأمنية</h3>
          <ul className="mt-3 divide-y divide-line">
            {headers.map((h) => (
              <li key={h.name} className="flex items-center justify-between gap-3 py-2">
                <span dir="ltr" className="font-mono text-[13px]">{h.name}</span>
                <StatusIcon status={h.present ? "pass" : "fail"} className="h-4 w-4" />
              </li>
            ))}
          </ul>
        </div>
      </div>

      <ChecksList checks={section.checks} />
    </div>
  );
}

function Info({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div>
      <dt className="text-muted">{label}</dt>
      <dd dir={ltr ? "ltr" : undefined} className={`mt-1 font-medium ${ltr ? "text-right font-mono text-[13px]" : ""}`}>
        {value}
      </dd>
    </div>
  );
}
