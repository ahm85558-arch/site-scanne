import {
  BarChart3, Boxes, Cloud, Code2, CreditCard, FileText, Globe, HardDrive,
  Megaphone, Palette, Puzzle, Server, ShieldCheck, ShoppingCart, Type, type LucideIcon,
} from "lucide-react";
import type { TechItem } from "@/lib/types";
import PanelHeader from "../PanelHeader";

// أسماء الفئات بالعربية مطابقة لقيم category في الـ Backend
const CATEGORIES: Record<string, { label: string; icon: LucideIcon }> = {
  cms: { label: "إدارة المحتوى", icon: FileText },
  ecommerce: { label: "التجارة الإلكترونية", icon: ShoppingCart },
  framework: { label: "إطارات العمل", icon: Boxes },
  js_library: { label: "مكتبات JavaScript", icon: Code2 },
  ui: { label: "التنسيق والواجهة", icon: Palette },
  fonts: { label: "الخطوط والأيقونات", icon: Type },
  backend: { label: "لغات الخادم", icon: Server },
  server: { label: "خوادم الويب", icon: HardDrive },
  cdn: { label: "شبكات توزيع المحتوى", icon: Globe },
  hosting: { label: "الاستضافة", icon: Cloud },
  analytics: { label: "التحليلات", icon: BarChart3 },
  marketing: { label: "التسويق والتتبع", icon: Megaphone },
  payments: { label: "الدفع", icon: CreditCard },
  security: { label: "الحماية", icon: ShieldCheck },
  widgets: { label: "إضافات", icon: Puzzle },
};

export default function TechPanel({ items }: { items: TechItem[] }) {
  const groups = items.reduce<Record<string, TechItem[]>>((acc, item) => {
    (acc[item.category] ??= []).push(item);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <PanelHeader
        title="التقنيات المستخدمة"
        summary={`اكتشفنا ${items.length} تقنية من الترويسات والكوكيز وكود الصفحة. نسبة الثقة تعكس عدد الأدلة.`}
      />

      {items.length === 0 ? (
        <div className="panel p-8 text-center text-muted">
          لم نتعرف على تقنيات معروفة. قد يكون الموقع مبنياً بأدوات مخصصة أو يُخفي بصماته.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(groups).map(([category, techs]) => {
            const meta = CATEGORIES[category] ?? { label: category, icon: Puzzle };
            const Icon = meta.icon;
            return (
              <div key={category} className="panel p-5">
                <h3 className="flex items-center gap-2 font-semibold">
                  <Icon className="h-4 w-4 text-accent" />
                  {meta.label}
                </h3>
                <ul className="mt-4 space-y-3">
                  {techs.map((t) => (
                    <li key={t.name}>
                      <div className="flex items-baseline justify-between gap-2">
                        <span dir="ltr" className="font-medium">{t.name}</span>
                        {t.version && <span dir="ltr" className="font-mono text-xs text-muted">v{t.version}</span>}
                      </div>
                      <div className="mt-1.5 h-1 rounded-full bg-paper" title={`الثقة ${t.confidence}%`}>
                        <div className="h-full rounded-full bg-accent" style={{ width: `${t.confidence}%` }} />
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
