"use client";

import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { SeoData, Section } from "@/lib/types";
import { hostnameOf } from "@/lib/format";
import ChecksList from "../ChecksList";
import PanelHeader from "../PanelHeader";
import { StatusIcon } from "../status";

export default function SeoPanel({ section, url }: { section: Section<SeoData>; url: string }) {
  const d = section.data;
  const headingData = ["h1", "h2", "h3", "h4", "h5", "h6"].map((h) => ({ name: h.toUpperCase(), count: d.heading_counts[h] ?? 0 }));

  return (
    <div className="space-y-6">
      <PanelHeader title="محركات البحث" score={section.score} summary="كيف تقرأ Google صفحتك، وما الذي يمنعها من الظهور بشكل أفضل." />

      {/* معاينة نتيجة البحث كما تظهر في Google */}
      <div className="panel p-5">
        <h3 className="font-semibold">معاينة نتيجة البحث</h3>
        <div dir="auto" className="mt-4 max-w-[600px] rounded-lg border border-line p-4">
          <p className="text-xs text-[#202124]">{hostnameOf(url)}</p>
          <p className="mt-1 truncate text-xl text-[#1a0dab]">{d.title || "(الصفحة بدون عنوان)"}</p>
          <p className="mt-1 line-clamp-2 text-sm text-[#4d5156]">
            {d.description || "لا يوجد وصف. ستختار Google مقتطفاً عشوائياً من محتوى الصفحة."}
          </p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* عدد العناوين */}
        <div className="panel p-5">
          <h3 className="font-semibold">العناوين</h3>
          <div className="mt-4 h-44" dir="ltr">
            <ResponsiveContainer>
              <BarChart data={headingData}>
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#5B667A" }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} width={28} tick={{ fontSize: 12, fill: "#5B667A" }} axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: "#F2F5F9" }} formatter={(v: number) => [v, "العدد"]} />
                <Bar dataKey="count" fill="#3A36B8" radius={[6, 6, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* المخطط الهرمي للعناوين */}
          <ul className="mt-4 max-h-56 space-y-1 overflow-y-auto border-t border-line pt-3 text-sm">
            {d.headings.map((h, i) => (
              <li key={i} className="flex items-baseline gap-2" style={{ paddingInlineStart: (h.level - 1) * 14 }}>
                <span className="font-mono text-[11px] text-muted">H{h.level}</span>
                <span className="truncate">{h.text || "(فارغ)"}</span>
              </li>
            ))}
            {!d.headings.length && <li className="text-muted">لا توجد عناوين في الصفحة.</li>}
          </ul>
        </div>

        {/* ملفات الزحف والروابط */}
        <div className="panel space-y-4 p-5">
          <h3 className="font-semibold">الزحف والروابط</h3>
          <Row status={d.robots.found && !d.robots.disallow_all ? "pass" : "warn"} label="robots.txt"
               detail={d.robots.found ? (d.robots.disallow_all ? "يمنع كل الروبوتات" : "موجود") : "غير موجود"} />
          <Row status={d.sitemap.found ? "pass" : "warn"} label="sitemap.xml"
               detail={d.sitemap.found ? `${d.sitemap.url_count} رابط${d.sitemap.is_index ? " (فهرس)" : ""}` : "غير موجود"} />
          <Row status={d.canonical ? "pass" : "warn"} label="Canonical" detail={d.canonical ? "موجود" : "مفقود"} />
          <div className="grid grid-cols-3 gap-2 border-t border-line pt-4 text-center">
            <Mini label="داخلية" value={d.links.internal} />
            <Mini label="خارجية" value={d.links.external} />
            <Mini label="معطلة" value={d.links.broken.length} danger={d.links.broken.length > 0} />
          </div>
        </div>
      </div>

      {/* جدول الروابط المعطلة */}
      {d.links.broken.length > 0 && (
        <div className="panel overflow-hidden">
          <h3 className="border-b border-line p-4 font-semibold">الروابط المعطلة</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-paper text-muted">
                <tr>
                  <th className="p-3 text-right font-medium">الرابط</th>
                  <th className="p-3 text-right font-medium">النوع</th>
                  <th className="p-3 text-right font-medium">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {d.links.broken.map((l) => (
                  <tr key={l.url}>
                    <td dir="ltr" className="code max-w-md p-3 text-left">{l.url}</td>
                    <td className="p-3">{l.internal ? "داخلي" : "خارجي"}</td>
                    <td className="p-3 font-medium text-fail">{l.status ?? l.error}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ChecksList checks={section.checks} />
    </div>
  );
}

function Row({ status, label, detail }: { status: "pass" | "warn"; label: string; detail: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="flex items-center gap-2">
        <StatusIcon status={status} className="h-4 w-4" />
        <span dir="ltr" className="font-mono text-[13px]">{label}</span>
      </span>
      <span className="text-sm text-muted">{detail}</span>
    </div>
  );
}

function Mini({ label, value, danger }: { label: string; value: number; danger?: boolean }) {
  return (
    <div>
      <p className={`text-2xl font-semibold ${danger ? "text-fail" : ""}`}>{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}
