import { ExternalLink, ShieldAlert, ShieldCheck, ShieldQuestion, type LucideIcon } from "lucide-react";
import type { Section, ThreatData, Verdict } from "@/lib/types";
import ChecksList from "../ChecksList";
import PanelHeader from "../PanelHeader";
import { STATUS_META } from "../status";

/** الحكم النهائي على الموقع: نص ولون وأيقونة */
export const VERDICT_META: Record<Verdict, { status: "pass" | "warn" | "fail"; short: string; title: string; advice: string; icon: LucideIcon }> = {
  clean: {
    status: "pass",
    short: "لا مؤشرات خطر",
    title: "لم نجد مؤشرات خطر",
    advice: "الموقع غير مُدرج في قوائم المواقع الخطيرة ولا يحتوي أنماطاً مشبوهة معروفة. هذا لا يضمن الأمان 100%.",
    icon: ShieldCheck,
  },
  suspicious: {
    status: "warn",
    short: "مشبوه",
    title: "الموقع مشبوه",
    advice: "وجدنا مؤشرات تستدعي الحذر. لا تُدخل كلمات مرور أو بيانات بنكية قبل التأكد من أن الرابط رسمي.",
    icon: ShieldQuestion,
  },
  dangerous: {
    status: "fail",
    short: "خطير",
    title: "الموقع خطير",
    advice: "لا تُدخل أي بيانات ولا تحمّل أي ملفات منه. إن وصلك الرابط في رسالة فغالباً هو احتيال.",
    icon: ShieldAlert,
  },
};

export default function ThreatPanel({ section }: { section: Section<ThreatData> }) {
  const { verdict, domain, safe_browsing: sb, virustotal: vt } = section.data;
  const meta = VERDICT_META[verdict];
  const tone = STATUS_META[meta.status];
  const Icon = meta.icon;

  return (
    <div className="space-y-6">
      <PanelHeader title="التهديدات والسمعة" score={section.score} summary="هل الموقع نفسه خطير أو احتيالي؟ نفحص قوائم السمعة العالمية وعمر النطاق ومحتوى الصفحة." />

      {/* الحكم النهائي */}
      <div className={`flex items-start gap-4 rounded-2xl p-5 ${tone.soft}`} style={{ borderInlineStart: `4px solid ${tone.hex}` }}>
        <Icon className={`h-8 w-8 shrink-0 ${tone.text}`} />
        <div>
          <p className={`text-xl font-semibold ${tone.text}`}>{meta.title}</p>
          <p className="mt-1 max-w-[65ch] text-sm text-ink">{meta.advice}</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {/* عمر النطاق */}
        <div className="panel p-5">
          <p className="text-sm text-muted">عمر النطاق</p>
          <p className="mt-1 text-2xl font-semibold">{formatAge(domain.age_days)}</p>
          <p dir="ltr" className="mt-2 text-right font-mono text-xs text-muted">{domain.name}</p>
          {domain.registrar && <p className="mt-1 text-xs text-muted">المسجّل: {domain.registrar}</p>}
        </div>

        {/* Google Safe Browsing */}
        <div className="panel p-5">
          <p className="text-sm text-muted">Google Safe Browsing</p>
          {!sb ? (
            <NotEnabled />
          ) : sb.error ? (
            <p className="mt-2 text-sm text-warn">{sb.error}</p>
          ) : sb.threats && sb.threats.length > 0 ? (
            <p className="mt-1 text-2xl font-semibold text-fail">مُدرج كخطير</p>
          ) : (
            <p className="mt-1 text-2xl font-semibold text-pass">نظيف</p>
          )}
        </div>

        {/* VirusTotal */}
        <div className="panel p-5">
          <p className="text-sm text-muted">VirusTotal</p>
          {!vt ? (
            <NotEnabled />
          ) : vt.error ? (
            <p className="mt-2 text-sm text-warn">{vt.error}</p>
          ) : (
            <>
              <p className={`mt-1 text-2xl font-semibold ${(vt.malicious ?? 0) > 0 ? "text-fail" : "text-pass"}`}>
                {vt.malicious ?? 0} خبيث
              </p>
              <p className="mt-1 text-xs text-muted">
                من {(vt.malicious ?? 0) + (vt.suspicious ?? 0) + (vt.harmless ?? 0) + (vt.undetected ?? 0)} محرك فحص
              </p>
              {vt.permalink && (
                <a href={vt.permalink} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs text-accent hover:underline">
                  التقرير الكامل <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </>
          )}
        </div>
      </div>

      <ChecksList checks={section.checks} />
    </div>
  );
}

function NotEnabled() {
  return <p className="mt-2 text-sm text-muted">غير مفعّل. يحتاج مفتاحاً مجانياً.</p>;
}

function formatAge(days: number | null): string {
  if (days == null) return "غير معروف";
  if (days < 30) return `${days} يوماً`;
  if (days < 365) return `${Math.floor(days / 30)} شهراً`;
  const years = Math.floor(days / 365);
  return years === 1 ? "سنة" : years === 2 ? "سنتان" : `${years} سنوات`;
}
