import { AlertTriangle, CheckCircle2, Info, XCircle, type LucideIcon } from "lucide-react";
import type { Status } from "@/lib/types";

/** تعريف موحّد لكل حالة: الاسم، الأيقونة، والألوان */
export const STATUS_META: Record<Status, { label: string; icon: LucideIcon; text: string; soft: string; hex: string }> = {
  fail: { label: "فشل", icon: XCircle, text: "text-fail", soft: "bg-fail-soft", hex: "#C2362F" },
  warn: { label: "تحذير", icon: AlertTriangle, text: "text-warn", soft: "bg-warn-soft", hex: "#B7791F" },
  pass: { label: "ناجح", icon: CheckCircle2, text: "text-pass", soft: "bg-pass-soft", hex: "#17865A" },
  info: { label: "معلومة", icon: Info, text: "text-muted", soft: "bg-paper", hex: "#5B667A" },
};

export function StatusIcon({ status, className = "h-5 w-5" }: { status: Status; className?: string }) {
  const { icon: Icon, text, label } = STATUS_META[status];
  return <Icon className={`${className} ${text} shrink-0`} aria-label={label} />;
}

export function StatusPill({ status, children }: { status: Status; children: React.ReactNode }) {
  const meta = STATUS_META[status];
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${meta.soft} ${meta.text}`}>
      {children}
    </span>
  );
}
