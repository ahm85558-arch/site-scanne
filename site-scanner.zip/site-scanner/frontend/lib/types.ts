// أنواع TypeScript مطابقة تماماً لاستجابة الـ Backend (app/models.py)

export type Status = "pass" | "warn" | "fail" | "info";

export interface Check {
  id: string;
  title: string;
  status: Status;
  message: string;
  value?: unknown;
}

export interface Section<T> {
  score: number;
  checks: Check[];
  data: T;
}

export interface SslInfo {
  valid: boolean;
  error?: string;
  issuer?: string | null;
  subject?: string | null;
  issued_at?: string;
  expires_at?: string;
  days_left?: number;
  tls_version?: string | null;
  san?: string[];
}

export interface HeaderRow {
  name: string;
  present: boolean;
  value: string | null;
}

export interface SecurityData {
  ssl: SslInfo | null;
  headers: HeaderRow[];
}

export interface ResourceBucket {
  count: number;
  bytes: number;
}

export interface WebVitals {
  strategy: string;
  lighthouse_score: number | null;
  lcp_ms: number | null;
  cls: number | null;
  tbt_ms: number | null;
  fcp_ms: number | null;
  si_ms: number | null;
  tti_ms: number | null;
  field: { lcp_ms: number | null; inp_ms: number | null; cls: number | null } | null;
}

export interface PerformanceData {
  ttfb_ms: number;
  total_ms: number;
  html_bytes: number;
  page_weight_bytes: number;
  http_version: string;
  compression: string | null;
  resources: {
    scripts: ResourceBucket;
    stylesheets: ResourceBucket;
    images: ResourceBucket;
    measured: number;
    uncached: number;
  };
  web_vitals: WebVitals | null;
  web_vitals_error: string | null;
}

export interface Heading {
  level: number;
  text: string;
}

export interface BrokenLink {
  url: string;
  status: number | null;
  error: string | null;
  internal: boolean;
}

export interface SeoData {
  title: string;
  description: string;
  canonical: string | null;
  lang: string | null;
  headings: Heading[];
  heading_counts: Record<string, number>;
  links: {
    total: number;
    internal: number;
    external: number;
    checked: number;
    restricted: number;
    broken: BrokenLink[];
  };
  robots: { found: boolean; url: string; sitemaps: string[]; disallow_all: boolean };
  sitemap: { found: boolean; url: string | null; url_count: number; is_index: boolean };
  images: { total: number; missing_alt: number };
  og: { title: string; description: string; image: string };
}

export type Verdict = "clean" | "suspicious" | "dangerous";

export interface ThreatData {
  verdict: Verdict;
  domain: {
    name: string;
    available: boolean;
    created_at: string | null;
    age_days: number | null;
    registrar: string | null;
  };
  safe_browsing: { threats?: string[]; error?: string } | null;
  virustotal: {
    malicious?: number;
    suspicious?: number;
    harmless?: number;
    undetected?: number;
    reputation?: number;
    permalink?: string;
    error?: string;
  } | null;
}

export interface TechItem {
  name: string;
  category: string;
  version: string | null;
  confidence: number;
}

export interface ScanResult {
  url: string;
  final_url: string;
  status_code: number;
  scanned_at: string;
  duration_ms: number;
  overall_score: number;
  security: Section<SecurityData>;
  performance: Section<PerformanceData>;
  seo: Section<SeoData>;
  threats: Section<ThreatData>;
  tech_stack: TechItem[];
}
