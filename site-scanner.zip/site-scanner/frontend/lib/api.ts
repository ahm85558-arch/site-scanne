import type { ScanResult } from "./types";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

/** يرسل الرابط للخادم ويعيد التقرير الكامل، مع رسائل خطأ مفهومة للمستخدم. */
export async function scanWebsite(url: string, signal?: AbortSignal): Promise<ScanResult> {
  let response: Response;
  try {
    response = await fetch(`${API_URL}/api/scan`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      signal,
    });
  } catch (error) {
    if ((error as Error).name === "AbortError") throw error;
    throw new Error(`لا يمكن الوصول إلى خادم الفحص على ${API_URL}. تأكد أنه يعمل.`);
  }

  if (!response.ok) {
    let detail = `فشل الفحص (رمز ${response.status})`;
    try {
      const body = await response.json();
      if (typeof body.detail === "string") detail = body.detail;
    } catch {
      /* الاستجابة ليست JSON — نبقي الرسالة الافتراضية */
    }
    throw new Error(detail);
  }
  return response.json();
}
