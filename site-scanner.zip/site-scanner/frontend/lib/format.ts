/** تنسيق البايتات: 1536 ← "1.5 KB" */
export function formatBytes(bytes: number | null | undefined): string {
  if (bytes == null) return "—";
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let value = bytes / 1024;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(value < 10 ? 1 : 0)} ${units[i]}`;
}

/** تنسيق الزمن: 850 ← "850 ms" و 2300 ← "2.30 s" */
export function formatMs(ms: number | null | undefined): string {
  if (ms == null) return "—";
  return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(2)} s`;
}

/** لون ووصف الدرجة: 80+ جيد، 50+ يحتاج تحسين، أقل ضعيف */
export function scoreTone(score: number) {
  if (score >= 80) return { label: "جيد", hex: "#17865A", text: "text-pass" };
  if (score >= 50) return { label: "يحتاج تحسين", hex: "#B7791F", text: "text-warn" };
  return { label: "ضعيف", hex: "#C2362F", text: "text-fail" };
}

/** تصنيف قيمة وفق عتبتين (أقل = أفضل) — نفس منطق الـ Backend */
export function rateValue(value: number, good: number, poor: number): "pass" | "warn" | "fail" {
  if (value <= good) return "pass";
  return value <= poor ? "warn" : "fail";
}

export function hostnameOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}
