# فاحص المواقع الشامل (Website Scanner)

منصة تفحص أي رابط وتعرض تقريراً تفاعلياً في خمسة أقسام: التهديدات والسمعة، الأمان، الأداء، SEO، والتقنيات.

## التقنيات

| الطبقة | التقنية | السبب |
|---|---|---|
| Backend | Python 3.11 + FastAPI | async سريع، توثيق تلقائي على `/docs` |
| HTTP | httpx (HTTP/2) | طلبات متوازية + event hooks لحماية SSRF |
| تحليل HTML | BeautifulSoup + lxml | أسرع محلل HTML في Python |
| Core Web Vitals | Google PageSpeed Insights API | يشغّل Lighthouse الحقيقي دون تثبيت Chrome |
| Frontend | Next.js 14 (App Router) + TypeScript | |
| التنسيق | TailwindCSS | |
| الرسوم | Recharts | |

## هيكل المشروع

```
site-scanner/
├── backend/
│   ├── requirements.txt
│   ├── .env.example
│   └── app/
│       ├── main.py               # نقطة الدخول: POST /api/scan
│       ├── config.py             # الإعدادات من .env
│       ├── models.py             # نماذج Pydantic للطلب والاستجابة
│       ├── services/
│       │   ├── snapshot.py       # جلب الصفحة مرة واحدة ومشاركتها
│       │   └── scan_service.py   # تنسيق الماسحات بالتوازي
│       ├── scanners/
│       │   ├── security.py       # SSL، الترويسات، CORS، الكوكيز، الملفات المكشوفة
│       │   ├── performance.py    # TTFB، الحجم، الضغط، Core Web Vitals
│       │   ├── seo.py            # Meta، العناوين، robots، sitemap، الروابط المعطلة
│       │   ├── threats.py        # السمعة، عمر النطاق، التصيّد، التعدين، الكود المشوّش
│       │   └── tech_stack.py     # كشف التقنيات بالتوقيعات
│       └── utils/
│           ├── url_guard.py      # الحماية من SSRF
│           ├── http_client.py    # عميل HTTP موحّد
│           └── scoring.py        # حساب الدرجات
└── frontend/
    ├── app/                      # layout.tsx, page.tsx, globals.css
    ├── components/
    │   ├── Overview.tsx, ScoreSeal.tsx, ScoreRing.tsx
    │   ├── ScanForm.tsx, ScanProgress.tsx, ChecksList.tsx
    │   └── panels/               # Security, Performance, Seo, Tech
    └── lib/                      # api.ts, types.ts, format.ts
```

## التشغيل

المتطلبات: Python 3.11+ و Node.js 18.18+

### 1) الخلفية

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # على Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # ضع مفتاح PageSpeed (اختياري)
uvicorn app.main:app --reload --port 8000
```

اختبر: افتح http://localhost:8000/docs أو:

```bash
curl -X POST http://localhost:8000/api/scan -H "Content-Type: application/json" -d '{"url":"example.com"}'
```

### 2) الواجهة

```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

افتح http://localhost:3000

### مفاتيح فحص التهديدات (اختيارية ومجانية)

- `GOOGLE_SAFE_BROWSING_KEY`: من Google Cloud Console فعّل "Safe Browsing API" وأنشئ مفتاحاً (نفس المشروع الذي فيه مفتاح PageSpeed يكفي).
- `VIRUSTOTAL_API_KEY`: سجّل في virustotal.com ثم افتح صفحة API Key من قائمة حسابك.

بدونهما يعمل فحص عمر النطاق ومؤشرات الصفحة فقط.

### مفتاح PageSpeed Insights

بدون مفتاح ستصل سريعاً لحد الطلبات (خطأ 429). المفتاح مجاني:
Google Cloud Console ← أنشئ مشروعاً ← فعّل "PageSpeed Insights API" ← Credentials ← Create API key
ثم ضعه في `backend/.env` تحت `PAGESPEED_API_KEY`.

## قبل النشر للإنتاج

- **تحديد معدل الطلبات**: أضف `slowapi` أو حدّاً على مستوى الـ reverse proxy، فكل فحص يرسل عشرات الطلبات.
- **طابور مهام**: الفحص يستغرق حتى دقيقة؛ مع زيادة المستخدمين انقله إلى Celery/RQ + Redis وأرجع `job_id` للواجهة.
- **التخزين المؤقت**: خزّن نتيجة كل نطاق 10–30 دقيقة لتوفير حصة PageSpeed.
- **عزل الشبكة**: شغّل الـ Backend في بيئة لا تصل للشبكة الداخلية (حماية إضافية ضد DNS Rebinding).
- **CORS**: حدّث `CORS_ORIGINS` برابط الواجهة الحقيقي.
- **الاستخدام القانوني**: أضف شروط استخدام تُلزم المستخدم بفحص مواقع يملكها أو مخوَّل بفحصها.
