"""نماذج البيانات (Pydantic) — تمثل شكل الطلب والاستجابة في الـ API."""
from typing import Any, Literal

from pydantic import BaseModel, Field

# حالة كل فحص: ناجح / تحذير / فشل / معلومة (لا تؤثر على الدرجة)
Status = Literal["pass", "warn", "fail", "info"]


class Check(BaseModel):
    """نتيجة فحص واحد (مثل: هل ترويسة HSTS موجودة؟)."""
    id: str
    title: str
    status: Status
    message: str
    value: Any | None = None


class SectionResult(BaseModel):
    """نتيجة قسم كامل (الأمان، الأداء، SEO) مع درجة من 100."""
    score: int = Field(ge=0, le=100)
    checks: list[Check] = Field(default_factory=list)
    data: dict[str, Any] = Field(default_factory=dict)


class TechItem(BaseModel):
    """تقنية مكتشفة في الموقع."""
    name: str
    category: str
    version: str | None = None
    confidence: int = Field(default=100, ge=0, le=100)


class ScanRequest(BaseModel):
    url: str = Field(min_length=3, max_length=2048)


class ScanResponse(BaseModel):
    url: str
    final_url: str
    status_code: int
    scanned_at: str
    duration_ms: int
    overall_score: int
    security: SectionResult
    performance: SectionResult
    seo: SectionResult
    tech_stack: list[TechItem]
