"""إعدادات التطبيق المركزية — تُقرأ من متغيرات البيئة أو من ملف .env"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # مفتاح Google PageSpeed Insights (اختياري لكنه يرفع حدّ الطلبات)
    pagespeed_api_key: str | None = None
    # مفاتيح فحص السمعة (اختيارية — مجانية)
    google_safe_browsing_key: str | None = None
    virustotal_api_key: str | None = None
    # مهلة طلبات HTTP العادية بالثواني
    request_timeout: float = 15.0
    # مهلة PageSpeed — تشغيل Lighthouse يستغرق وقتاً أطول
    pagespeed_timeout: float = 90.0
    # الحد الأقصى للروابط التي نفحصها بحثاً عن الروابط المعطلة
    max_links_to_check: int = 40
    # الحد الأقصى للموارد (JS/CSS/صور) التي نقيس حجمها
    max_resources_to_measure: int = 40
    # أقصى حجم HTML نقرؤه (5 ميجابايت) لحماية ذاكرة الخادم
    max_html_bytes: int = 5 * 1024 * 1024
    # النطاقات المسموح لها باستدعاء الـ API
    cors_origins: list[str] = ["http://localhost:3000"]
    user_agent: str = "Mozilla/5.0 (compatible; SiteScanner/1.0)"


settings = Settings()
