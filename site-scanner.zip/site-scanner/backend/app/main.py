"""
نقطة الدخول لخادم FastAPI
التشغيل:  uvicorn app.main:app --reload --port 8000
التوثيق التفاعلي: http://localhost:8000/docs
"""
import logging

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.models import ScanRequest, ScanResponse
from app.services.scan_service import run_scan
from app.utils.url_guard import UnsafeURLError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("site-scanner")

app = FastAPI(
    title="Website Scanner API",
    description="فحص شامل للمواقع: الأمان، الأداء، SEO، والتقنيات المستخدمة",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


@app.get("/api/health")
async def health() -> dict:
    return {"status": "ok"}


@app.post("/api/scan", response_model=ScanResponse)
async def scan(request: ScanRequest) -> ScanResponse:
    try:
        return await run_scan(request.url)
    except UnsafeURLError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="الموقع لم يستجب خلال المهلة المحددة") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"تعذّر الوصول إلى الموقع: {type(exc).__name__}") from exc
    except Exception as exc:  # نسجّل الخطأ كاملاً في الخادم ولا نكشف تفاصيله للمستخدم
        logger.exception("Unexpected scan failure for %s", request.url)
        raise HTTPException(status_code=500, detail="حدث خطأ غير متوقع أثناء الفحص") from exc
