"""
لقطة الصفحة (PageSnapshot)
==========================
نجلب الصفحة مرة واحدة فقط ونشاركها بين كل الماسحات (الأمان، الأداء، SEO، التقنيات)
بدلاً من أن يجلبها كل ماسح بنفسه.
"""
import time
from dataclasses import dataclass, field
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

from app.config import settings


@dataclass
class PageSnapshot:
    requested_url: str
    final_url: str
    status_code: int
    headers: httpx.Headers
    html: str
    soup: BeautifulSoup
    ttfb_ms: int            # الزمن حتى وصول أول بايت (Time To First Byte)
    total_ms: int           # الزمن الكلي لتحميل مستند HTML
    html_bytes: int         # حجم HTML بعد فك الضغط
    http_version: str
    ssl_verified: bool
    redirect_chain: list[str] = field(default_factory=list)

    @property
    def is_https(self) -> bool:
        return self.final_url.startswith("https://")

    @property
    def host(self) -> str:
        return urlparse(self.final_url).hostname or ""

    @property
    def origin(self) -> str:
        parsed = urlparse(self.final_url)
        return f"{parsed.scheme}://{parsed.netloc}"

    @property
    def set_cookies(self) -> list[str]:
        return self.headers.get_list("set-cookie")


async def fetch_snapshot(client: httpx.AsyncClient, url: str, ssl_verified: bool = True) -> PageSnapshot:
    start = time.perf_counter()
    async with client.stream("GET", url) as resp:
        # عند الدخول لهذا السياق تكون الترويسات قد وصلت ← هذا هو TTFB تقريباً
        ttfb = time.perf_counter()
        chunks: list[bytes] = []
        size = 0
        async for chunk in resp.aiter_bytes():
            size += len(chunk)
            chunks.append(chunk)
            if size > settings.max_html_bytes:
                break  # نتوقف لحماية الذاكرة من الصفحات الضخمة
        end = time.perf_counter()

        raw = b"".join(chunks)
        html = raw.decode(resp.encoding or "utf-8", errors="replace")
        return PageSnapshot(
            requested_url=url,
            final_url=str(resp.url),
            status_code=resp.status_code,
            headers=resp.headers,
            html=html,
            soup=BeautifulSoup(html, "lxml"),
            ttfb_ms=round((ttfb - start) * 1000),
            total_ms=round((end - start) * 1000),
            html_bytes=len(raw),
            http_version=resp.http_version,
            ssl_verified=ssl_verified,
            redirect_chain=[str(r.url) for r in resp.history],
        )
