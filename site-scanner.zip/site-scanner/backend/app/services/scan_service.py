"""
منسّق الفحص (Orchestrator)
=========================
1) يتحقق من الرابط ويحميه من SSRF.
2) يجلب الصفحة مرة واحدة (PageSnapshot).
3) يشغّل ماسحات الأمان والأداء وSEO بالتوازي، ثم يكتشف التقنيات.
4) يحسب الدرجة الإجمالية ويُرجع التقرير.
"""
import asyncio
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

import httpx

from app.models import ScanResponse
from app.scanners.performance import scan_performance
from app.scanners.security import scan_security
from app.scanners.seo import scan_seo
from app.scanners.tech_stack import detect_tech_stack
from app.scanners.threats import scan_threats
from app.services.snapshot import PageSnapshot, fetch_snapshot
from app.utils.http_client import build_client
from app.utils.url_guard import assert_public_host, normalize_url

# وزن كل قسم في الدرجة الإجمالية
SECTION_WEIGHTS = {"security": 0.30, "threats": 0.25, "performance": 0.20, "seo": 0.25}


def _is_certificate_error(exc: Exception) -> bool:
    return "certificate" in str(exc).lower()


async def _fetch_with_fallbacks(raw_url: str, url: str) -> tuple[PageSnapshot, httpx.AsyncClient]:
    """
    يحاول جلب الصفحة بأكثر من طريقة:
    - إن فشل التحقق من الشهادة نكمل بدون تحقق كي نعطي تقريراً كاملاً (ونسجّل المشكلة).
    - إن لم يكتب المستخدم البروتوكول وفشل HTTPS نجرّب HTTP.
    """
    client = build_client(verify=True)
    try:
        return await fetch_snapshot(client, url), client
    except httpx.ConnectError as exc:
        await client.aclose()
        if _is_certificate_error(exc):
            client = build_client(verify=False)
            return await fetch_snapshot(client, url, ssl_verified=False), client
        if "://" not in raw_url:
            client = build_client(verify=True)
            return await fetch_snapshot(client, url.replace("https://", "http://", 1)), client
        raise
    except Exception:
        await client.aclose()
        raise


async def run_scan(raw_url: str) -> ScanResponse:
    started = time.perf_counter()
    url = normalize_url(raw_url)
    await asyncio.to_thread(assert_public_host, urlparse(url).hostname)

    snapshot, client = await _fetch_with_fallbacks(raw_url, url)
    try:
        security, performance, seo, threats = await asyncio.gather(
            scan_security(snapshot, client),
            scan_performance(snapshot, client),
            scan_seo(snapshot, client),
            scan_threats(snapshot),
        )
    finally:
        await client.aclose()

    tech_stack = detect_tech_stack(snapshot)
    overall = round(
        security.score * SECTION_WEIGHTS["security"]
        + threats.score * SECTION_WEIGHTS["threats"]
        + performance.score * SECTION_WEIGHTS["performance"]
        + seo.score * SECTION_WEIGHTS["seo"]
    )
    # الموقع الخطير لا يستحق درجة عالية مهما كانت جودة إعداداته
    verdict = threats.data["verdict"]
    if verdict == "dangerous":
        overall = min(overall, 20)
    elif verdict == "suspicious":
        overall = min(overall, 60)

    return ScanResponse(
        url=url,
        final_url=snapshot.final_url,
        status_code=snapshot.status_code,
        scanned_at=datetime.now(timezone.utc).isoformat(),
        duration_ms=round((time.perf_counter() - started) * 1000),
        overall_score=overall,
        security=security,
        performance=performance,
        seo=seo,
        threats=threats,
        tech_stack=tech_stack,
    )
