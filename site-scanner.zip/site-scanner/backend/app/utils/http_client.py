"""إنشاء عميل HTTP موحّد مع حماية SSRF على كل طلب (بما فيها التحويلات)."""
import asyncio

import httpx

from app.config import settings
from app.utils.url_guard import assert_public_host


async def _ssrf_guard(request: httpx.Request) -> None:
    """Event hook يُنفَّذ قبل إرسال أي طلب، حتى طلبات إعادة التوجيه."""
    await asyncio.to_thread(assert_public_host, request.url.host)


def build_client(verify: bool = True) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        http2=True,
        verify=verify,
        follow_redirects=True,
        max_redirects=5,
        timeout=httpx.Timeout(settings.request_timeout),
        limits=httpx.Limits(max_connections=20),
        headers={
            "User-Agent": settings.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "ar,en;q=0.8",
        },
        event_hooks={"request": [_ssrf_guard]},
    )
