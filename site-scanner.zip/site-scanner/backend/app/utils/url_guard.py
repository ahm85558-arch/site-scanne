"""
الحماية من هجمات SSRF (Server-Side Request Forgery)
===================================================
أي منصة تجلب روابط يرسلها المستخدم يمكن استغلالها لمهاجمة الشبكة الداخلية
للخادم نفسه (مثل 127.0.0.1 أو 169.254.169.254 حيث بيانات اعتماد السحابة).
لذلك نرفض أي رابط يُحَل إلى عنوان IP غير عام — ونعيد التحقق عند كل إعادة توجيه.
"""
import ipaddress
import socket
from urllib.parse import urlparse, urlunparse


class UnsafeURLError(ValueError):
    """رابط غير صالح أو يشير إلى عنوان داخلي محظور."""


def normalize_url(raw: str) -> str:
    """توحيد صيغة الرابط: إضافة https عند غيابه وحذف الـ fragment."""
    raw = (raw or "").strip()
    if not raw:
        raise UnsafeURLError("أدخل رابط الموقع المراد فحصه")
    if "://" not in raw:
        raw = f"https://{raw}"

    parsed = urlparse(raw)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise UnsafeURLError("الرابط غير صالح — يجب أن يبدأ بـ http:// أو https://")
    if parsed.username or parsed.password:
        raise UnsafeURLError("الروابط التي تحتوي اسم مستخدم أو كلمة مرور غير مسموحة")

    return urlunparse(parsed._replace(path=parsed.path or "/", fragment=""))


def assert_public_host(hostname: str | None) -> None:
    """
    يتأكد أن كل عناوين IP الخاصة بالنطاق عامة (Global).
    ملاحظة: يبقى هجوم DNS Rebinding ممكناً نظرياً؛ في بيئة الإنتاج
    يُفضّل تشغيل الفاحص داخل شبكة معزولة لا تصل للموارد الداخلية.
    """
    if not hostname:
        raise UnsafeURLError("اسم النطاق مفقود")
    try:
        infos = socket.getaddrinfo(hostname, None)
    except socket.gaierror as exc:
        raise UnsafeURLError(f"النطاق {hostname} غير موجود أو لا يمكن الوصول إليه") from exc

    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not ip.is_global or ip.is_multicast:
            raise UnsafeURLError("الرابط يشير إلى عنوان داخلي أو محجوز، ولا يمكن فحصه")
