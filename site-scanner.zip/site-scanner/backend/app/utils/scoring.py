"""حساب درجة القسم من نتائج الفحوصات بشكل موزون."""
from app.models import Check

# الفحص الناجح يأخذ كامل الوزن، التحذير نصفه، الفشل صفر. "info" لا يُحتسب.
STATUS_POINTS = {"pass": 1.0, "warn": 0.5, "fail": 0.0}


def score_checks(checks: list[Check], weights: dict[str, float] | None = None) -> int:
    weights = weights or {}
    total = earned = 0.0
    for check in checks:
        if check.status not in STATUS_POINTS:
            continue
        weight = weights.get(check.id, 1.0)
        total += weight
        earned += weight * STATUS_POINTS[check.status]
    return round(earned / total * 100) if total else 0


def rate(value: float, good: float, poor: float) -> str:
    """تصنيف قيمة رقمية وفق عتبتين (أقل = أفضل)."""
    if value <= good:
        return "pass"
    return "warn" if value <= poor else "fail"
