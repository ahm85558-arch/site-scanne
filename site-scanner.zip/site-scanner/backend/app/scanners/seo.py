"""
فحص محركات البحث (SEO Audit)
============================
Meta Tags، هيكل العناوين، الصور، البيانات المنظمة، robots.txt، sitemap، والروابط المعطلة.
"""
from __future__ import annotations

import asyncio
import re
from urllib.parse import urldefrag, urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from app.config import settings
from app.models import Check, SectionResult
from app.services.snapshot import PageSnapshot
from app.utils.scoring import score_checks
from app.utils.url_guard import UnsafeURLError

WEIGHTS = {"title": 3, "meta_description": 2, "h1": 2, "broken_links": 2.5, "noindex": 3,
           "viewport": 1.5, "robots_txt": 1, "sitemap": 1, "canonical": 1}

# رموز تعني أن الرابط معطّل فعلاً (لا مجرد محجوب عن الروبوتات)
BROKEN_STATUSES = {404, 410}
# رموز شائعة لحماية المواقع من الروبوتات — لا نعتبرها معطّلة
RESTRICTED_STATUSES = {401, 403, 429, 999}


async def scan_seo(snap: PageSnapshot, client: httpx.AsyncClient) -> SectionResult:
    soup = snap.soup
    checks: list[Check] = []

    # ---- العنوان والوصف
    title = soup.title.get_text(strip=True) if soup.title else ""
    checks.append(_length_check("title", "عنوان الصفحة (Title)", title, 10, 60))
    description = _meta(soup, name="description")
    checks.append(_length_check("meta_description", "الوصف (Meta Description)", description, 50, 160))

    # ---- العناوين H1-H6
    headings = [{"level": int(h.name[1]), "text": h.get_text(" ", strip=True)[:150]}
                for h in soup.find_all(re.compile(r"^h[1-6]$"))]
    counts = {f"h{i}": sum(1 for h in headings if h["level"] == i) for i in range(1, 7)}
    checks.append(_h1_check(counts["h1"]))
    checks.append(_hierarchy_check(headings))

    # ---- وسوم تقنية أساسية
    canonical_tag = soup.find("link", rel=lambda r: r and "canonical" in [x.lower() for x in r])
    canonical = canonical_tag.get("href") if canonical_tag else None
    checks.append(Check(id="canonical", title="الرابط الأساسي (Canonical)", status="pass" if canonical else "warn",
                        value=canonical, message=canonical or "مفقود — قد تظهر نسخ مكررة من الصفحة في نتائج البحث"))

    robots_meta = _meta(soup, name="robots").lower()
    noindex = "noindex" in robots_meta or "noindex" in snap.headers.get("x-robots-tag", "").lower()
    checks.append(Check(id="noindex", title="قابلية الأرشفة", status="fail" if noindex else "pass",
                        message="الصفحة تمنع محركات البحث من أرشفتها (noindex)!" if noindex else "مسموح بالأرشفة"))

    viewport = _meta(soup, name="viewport")
    checks.append(Check(id="viewport", title="التوافق مع الجوال (Viewport)", status="pass" if viewport else "fail",
                        message="موجود" if viewport else "وسم viewport مفقود — Google يعتمد على نسخة الجوال في الترتيب"))

    lang = soup.html.get("lang") if soup.html else None
    checks.append(Check(id="lang", title="لغة الصفحة", status="pass" if lang else "warn", value=lang,
                        message=f"lang=\"{lang}\"" if lang else "خاصية lang مفقودة من وسم <html>"))

    # ---- Open Graph (معاينة الروابط في الشبكات الاجتماعية)
    og = {key: _meta(soup, prop=f"og:{key}") for key in ("title", "description", "image")}
    og_count = sum(1 for v in og.values() if v)
    checks.append(Check(id="open_graph", title="وسوم Open Graph", status="pass" if og_count == 3 else "warn",
                        message=f"{og_count} من 3 وسوم أساسية (og:title, og:description, og:image)"))

    # ---- الصور
    images = soup.find_all("img")
    missing_alt = sum(1 for img in images if not (img.get("alt") or "").strip())
    if images:
        checks.append(Check(id="img_alt", title="النص البديل للصور (Alt)",
                            status="pass" if missing_alt == 0 else ("warn" if missing_alt / len(images) < 0.3 else "fail"),
                            message=f"{missing_alt} من {len(images)} صورة بدون نص بديل"))

    # ---- البيانات المنظمة
    json_ld = soup.find_all("script", attrs={"type": "application/ld+json"})
    checks.append(Check(id="structured_data", title="البيانات المنظمة (Schema.org)",
                        status="pass" if json_ld else "info",
                        message=f"{len(json_ld)} كتلة JSON-LD" if json_ld else "لا توجد — تساعد على الظهور بنتائج غنية"))

    # ---- رمز حالة HTTP
    checks.append(Check(id="status_code", title="رمز الحالة HTTP", status="pass" if snap.status_code == 200 else "warn",
                        value=snap.status_code, message=f"الصفحة ترجع {snap.status_code}"))

    # ---- الفحوصات الشبكية بالتوازي: robots.txt والروابط
    robots, links = await asyncio.gather(_check_robots(snap, client), _check_links(snap, client))
    sitemap = await _check_sitemap(snap, client, robots["sitemaps"])

    checks.append(Check(
        id="robots_txt", title="ملف robots.txt",
        status="fail" if robots["disallow_all"] else ("pass" if robots["found"] else "warn"),
        message="يمنع كل محركات البحث من الزحف (Disallow: /)!" if robots["disallow_all"]
        else ("موجود" if robots["found"] else "غير موجود"),
    ))
    checks.append(Check(
        id="sitemap", title="خريطة الموقع (Sitemap)", status="pass" if sitemap["found"] else "warn",
        message=f"موجودة وتحتوي {sitemap['url_count']} رابط" if sitemap["found"] else "لم نعثر على sitemap.xml",
    ))

    broken = len(links["broken"])
    checks.append(Check(
        id="broken_links", title="الروابط المعطلة", value=broken,
        status="pass" if broken == 0 else ("warn" if broken <= 2 else "fail"),
        message=f"فحصنا {links['checked']} رابط: " + ("لا توجد روابط معطلة" if broken == 0 else f"{broken} رابط معطّل"),
    ))

    return SectionResult(score=score_checks(checks, WEIGHTS), checks=checks, data={
        "title": title,
        "description": description,
        "canonical": canonical,
        "lang": lang,
        "headings": headings[:60],
        "heading_counts": counts,
        "links": links,
        "robots": robots,
        "sitemap": sitemap,
        "images": {"total": len(images), "missing_alt": missing_alt},
        "og": og,
    })


# ---------------------------------------------------------------- Helpers
def _meta(soup: BeautifulSoup, name: str | None = None, prop: str | None = None) -> str:
    """قراءة محتوى وسم meta بالاسم أو بالخاصية property (غير حساس لحالة الأحرف)."""
    key, value = ("name", name) if name else ("property", prop)
    tag = soup.find("meta", attrs={key: re.compile(rf"^{re.escape(value)}$", re.I)})
    return (tag.get("content") or "").strip() if tag else ""


def _length_check(check_id: str, title: str, text: str, minimum: int, maximum: int) -> Check:
    length = len(text)
    if not text:
        return Check(id=check_id, title=title, status="fail", message="مفقود")
    if length < minimum:
        return Check(id=check_id, title=title, status="warn", value=text, message=f"قصير جداً ({length} حرف) — الأفضل {minimum}–{maximum}")
    if length > maximum:
        return Check(id=check_id, title=title, status="warn", value=text, message=f"طويل ({length} حرف) — سيُقتطع في نتائج البحث")
    return Check(id=check_id, title=title, status="pass", value=text, message=f"طول مثالي ({length} حرف)")


def _h1_check(count: int) -> Check:
    if count == 1:
        return Check(id="h1", title="العنوان الرئيسي H1", status="pass", message="عنوان H1 واحد — ممتاز")
    if count == 0:
        return Check(id="h1", title="العنوان الرئيسي H1", status="fail", message="لا يوجد عنوان H1 في الصفحة")
    return Check(id="h1", title="العنوان الرئيسي H1", status="warn", message=f"يوجد {count} عناوين H1 — الأفضل عنوان واحد")


def _hierarchy_check(headings: list[dict]) -> Check:
    """التسلسل الصحيح: لا نقفز من H2 إلى H4 مباشرة."""
    skips = []
    previous = 0
    for h in headings:
        if previous and h["level"] > previous + 1:
            skips.append(f"H{previous} ← H{h['level']}")
        previous = h["level"]
    if skips:
        return Check(id="heading_hierarchy", title="تسلسل العناوين", status="warn", value=skips[:5],
                     message=f"قفزات في التسلسل: {'، '.join(skips[:3])}")
    return Check(id="heading_hierarchy", title="تسلسل العناوين", status="pass", message="العناوين مرتبة منطقياً")


async def _check_robots(snap: PageSnapshot, client: httpx.AsyncClient) -> dict:
    url = snap.origin + "/robots.txt"
    result = {"found": False, "url": url, "sitemaps": [], "disallow_all": False}
    try:
        resp = await client.get(url)
    except (httpx.HTTPError, UnsafeURLError):
        return result
    if resp.status_code != 200 or "html" in resp.headers.get("content-type", ""):
        return result

    text = resp.text
    result["found"] = True
    result["sitemaps"] = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", text)

    # نحلل المجموعات: هل مجموعة "User-agent: *" تحتوي "Disallow: /"؟
    agents: list[str] = []
    in_rules = False
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if ":" not in line:
            continue
        key, value = (part.strip() for part in line.split(":", 1))
        key = key.lower()
        if key == "user-agent":
            if in_rules:  # بداية مجموعة جديدة
                agents, in_rules = [], False
            agents.append(value)
        else:
            in_rules = True
            if key == "disallow" and value == "/" and "*" in agents:
                result["disallow_all"] = True
    return result


async def _check_sitemap(snap: PageSnapshot, client: httpx.AsyncClient, candidates: list[str]) -> dict:
    for url in (candidates[:3] or [snap.origin + "/sitemap.xml"]):
        try:
            resp = await client.get(url)
        except (httpx.HTTPError, UnsafeURLError):
            continue
        body = resp.text
        if resp.status_code == 200 and ("<urlset" in body or "<sitemapindex" in body):
            return {"found": True, "url": url, "url_count": body.count("<loc>"),
                    "is_index": "<sitemapindex" in body}
    return {"found": False, "url": None, "url_count": 0, "is_index": False}


async def _check_links(snap: PageSnapshot, client: httpx.AsyncClient) -> dict:
    """يجمع روابط الصفحة ويفحص عيّنة منها (الداخلية أولاً) بحثاً عن 404 والأخطاء."""
    links: dict[str, bool] = {}  # الرابط ← هل هو داخلي؟
    for a in snap.soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith(("#", "mailto:", "tel:", "javascript:", "data:")):
            continue
        absolute = urldefrag(urljoin(snap.final_url, href)).url
        if absolute.startswith(("http://", "https://")):
            links.setdefault(absolute, urlparse(absolute).hostname == snap.host)

    to_check = sorted(links, key=lambda u: not links[u])[: settings.max_links_to_check]
    semaphore = asyncio.Semaphore(10)

    async def probe(url: str) -> tuple[str, int | None, str | None]:
        async with semaphore:
            try:
                resp = await client.head(url)
                status = resp.status_code
                if status >= 400:
                    # كثير من الخوادم لا تدعم HEAD — نعيد المحاولة بـ GET دون قراءة المحتوى
                    async with client.stream("GET", url) as stream:
                        status = stream.status_code
                return url, status, None
            except UnsafeURLError:
                return url, -1, None  # رابط داخلي محظور — نتجاهله
            except httpx.TimeoutException:
                return url, None, "انتهت المهلة"
            except httpx.HTTPError as exc:
                return url, None, type(exc).__name__

    results = await asyncio.gather(*(probe(u) for u in to_check))

    broken, restricted = [], 0
    for url, status, error in results:
        if status in RESTRICTED_STATUSES:
            restricted += 1
        elif error or (status is not None and (status in BROKEN_STATUSES or status >= 500)):
            broken.append({"url": url, "status": status, "error": error, "internal": links[url]})

    internal = sum(1 for v in links.values() if v)
    return {"total": len(links), "internal": internal, "external": len(links) - internal,
            "checked": len(to_check), "broken": broken, "restricted": restricted}
