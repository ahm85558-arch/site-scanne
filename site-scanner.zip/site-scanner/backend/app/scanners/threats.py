"""
فحص التهديدات والسمعة (Threat & Reputation)
==========================================
يجيب عن سؤال: هل هذا الموقع نفسه خطير أو مشبوه؟ عبر ثلاث طبقات:

1) قوائم السمعة العالمية (اختيارية — تحتاج مفاتيح مجانية):
   - Google Safe Browsing: القائمة التي يستخدمها Chrome لحجب المواقع الخطيرة.
   - VirusTotal: نتائج أكثر من 90 محرك فحص أمني للنطاق.
2) عمر النطاق عبر RDAP (مجاني بلا مفتاح): مواقع التصيّد غالباً عمرها أيام.
3) مؤشرات داخل الصفحة: نماذج تسرق كلمات المرور، انتحال علامات تجارية،
   سكربتات تعدين عملات، كود مشوّش، iframes مخفية، تحويلات لنطاقات أخرى.

⚠️ غياب المؤشرات لا يعني أن الموقع آمن 100%، لكنه يكشف أغلب الحالات الشائعة.
"""
from __future__ import annotations

import asyncio
import ipaddress
import re
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import httpx

from app.config import settings
from app.models import Check, SectionResult
from app.services.snapshot import PageSnapshot
from app.utils.scoring import score_checks

SAFE_BROWSING_ENDPOINT = "https://safebrowsing.googleapis.com/v4/threatMatches:find"
VIRUSTOTAL_ENDPOINT = "https://www.virustotal.com/api/v3/domains/{domain}"
RDAP_ENDPOINT = "https://rdap.org/domain/{domain}"

WEIGHTS = {
    "safe_browsing": 5, "virustotal": 5, "phishing_form": 4, "crypto_miner": 4,
    "impersonation": 3, "domain_age": 2, "obfuscated_js": 2, "hidden_iframes": 2,
    "external_redirect": 1.5, "idn_homograph": 1.5, "ip_host": 1.5, "risky_tld": 1,
}

# فشل أي من هذه يعني أن الموقع "خطير" وليس مجرد "مشبوه"
CRITICAL_CHECKS = {"safe_browsing", "virustotal", "phishing_form", "crypto_miner"}

SAFE_BROWSING_TYPES = {
    "MALWARE": "برمجيات خبيثة",
    "SOCIAL_ENGINEERING": "تصيّد واحتيال",
    "UNWANTED_SOFTWARE": "برامج غير مرغوبة",
    "POTENTIALLY_HARMFUL_APPLICATION": "تطبيقات ضارة",
}

# امتدادات نطاقات رخيصة يكثر استخدامها في الاحتيال (مؤشر ضعيف وحده)
RISKY_TLDS = {"zip", "mov", "top", "xyz", "tk", "ml", "ga", "cf", "gq", "click", "country",
              "loan", "work", "rest", "cam", "icu", "buzz", "sbs", "cfd"}

# مقاطع المستوى الثاني الشائعة (com.sa / co.uk) لاستخراج النطاق الأساسي بدقة
SECOND_LEVEL = {"com", "net", "org", "gov", "edu", "co", "ac", "sch", "med"}

CRYPTO_MINERS = [r"coinhive", r"coin-hive", r"cryptoloot", r"crypto-loot", r"webminepool",
                 r"minero\.cc", r"coinimp", r"jsecoin", r"cryptonight"]

OBFUSCATION_PATTERNS = [
    (r"eval\s*\(\s*atob\s*\(", "eval(atob(...))"),
    (r"eval\s*\(\s*unescape\s*\(", "eval(unescape(...))"),
    (r"eval\s*\(\s*String\.fromCharCode\s*\(", "eval(String.fromCharCode(...))"),
    (r"eval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k\s*,\s*e", "Dean Edwards Packer"),
    (r"document\.write\s*\(\s*unescape\s*\(", "document.write(unescape(...))"),
]

# خدمات تستخدم iframe مخفياً بشكل مشروع (مثل Google Tag Manager)
TRUSTED_HIDDEN_FRAMES = {"googletagmanager.com", "doubleclick.net", "google.com", "facebook.com",
                         "bing.com", "linkedin.com", "twitter.com", "x.com", "tiktok.com", "hotjar.com"}

# (العلامة، كلمات تظهر في عنوان الصفحة، كلمات يجب أن تكون في النطاق الحقيقي)
BRANDS = [
    ("PayPal", ["paypal"], ["paypal"]),
    ("Apple", ["apple id", "icloud"], ["apple", "icloud"]),
    ("Microsoft", ["microsoft", "outlook", "office 365"], ["microsoft", "live", "office", "outlook"]),
    ("Google", ["gmail", "google account"], ["google"]),
    ("Netflix", ["netflix"], ["netflix"]),
    ("Amazon", ["amazon"], ["amazon"]),
    ("DHL", ["dhl"], ["dhl"]),
    ("مصرف الراجحي", ["al rajhi", "alrajhi", "الراجحي"], ["alrajhi"]),
    ("البنك الأهلي", ["alahli", "البنك الأهلي"], ["alahli", "snb"]),
    ("البنك السعودي الأول", ["saudi awwal", "البنك السعودي الأول"], ["sab"]),
    ("بنك الرياض", ["riyad bank", "بنك الرياض"], ["riyadbank"]),
    ("أبشر", ["absher", "أبشر"], ["absher", "gov.sa"]),
    ("stc pay", ["stc pay"], ["stcpay", "stc"]),
    ("سمسا", ["smsa"], ["smsa"]),
    ("البريد السعودي", ["saudi post", "البريد السعودي"], ["splonline", "sp.com.sa"]),
]


def registrable_domain(host: str) -> str:
    """sub.example.com.sa ← example.com.sa"""
    parts = host.lower().strip(".").split(".")
    if len(parts) >= 3 and parts[-2] in SECOND_LEVEL and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


async def scan_threats(snap: PageSnapshot) -> SectionResult:
    host = snap.host
    domain = host if _is_ip(host) else registrable_domain(host)

    safe_browsing, virustotal, domain_info = await asyncio.gather(
        _check_safe_browsing(list({snap.requested_url, snap.final_url})),
        _check_virustotal(domain),
        _fetch_domain_info(domain),
    )

    checks: list[Check] = [
        _safe_browsing_check(safe_browsing),
        _virustotal_check(virustotal),
        _domain_age_check(domain_info),
        *_page_checks(snap),
        *_url_checks(host),
    ]

    return SectionResult(score=score_checks(checks, WEIGHTS), checks=checks, data={
        "verdict": _verdict(checks),
        "domain": domain_info,
        "safe_browsing": safe_browsing,
        "virustotal": virustotal,
    })


def _verdict(checks: list[Check]) -> str:
    failed = {c.id for c in checks if c.status == "fail"}
    warnings = sum(1 for c in checks if c.status == "warn")
    if failed & CRITICAL_CHECKS:
        return "dangerous"
    if failed or warnings >= 2:
        return "suspicious"
    return "clean"


# ---------------------------------------------------------------- Reputation
async def _check_safe_browsing(urls: list[str]) -> dict | None:
    if not settings.google_safe_browsing_key:
        return None
    body = {
        "client": {"clientId": "site-scanner", "clientVersion": "1.0"},
        "threatInfo": {
            "threatTypes": list(SAFE_BROWSING_TYPES),
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": u} for u in urls],
        },
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(SAFE_BROWSING_ENDPOINT, params={"key": settings.google_safe_browsing_key}, json=body)
        resp.raise_for_status()
        matches = resp.json().get("matches", [])
    except (httpx.HTTPError, ValueError):
        return {"error": "تعذّر الاتصال بـ Google Safe Browsing"}
    return {"threats": sorted({m.get("threatType", "UNKNOWN") for m in matches})}


def _safe_browsing_check(result: dict | None) -> Check:
    title = "قائمة Google Safe Browsing"
    if result is None:
        return Check(id="safe_browsing", title=title, status="info",
                     message="غير مفعّل — أضف GOOGLE_SAFE_BROWSING_KEY لتفعيله")
    if "error" in result:
        return Check(id="safe_browsing", title=title, status="info", message=result["error"])
    if result["threats"]:
        labels = "، ".join(SAFE_BROWSING_TYPES.get(t, t) for t in result["threats"])
        return Check(id="safe_browsing", title=title, status="fail", value=result["threats"],
                     message=f"Google يصنّف هذا الموقع خطيراً: {labels}")
    return Check(id="safe_browsing", title=title, status="pass", message="غير مُدرج في قوائم Google للمواقع الخطيرة")


async def _check_virustotal(domain: str) -> dict | None:
    if not settings.virustotal_api_key:
        return None
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(VIRUSTOTAL_ENDPOINT.format(domain=domain),
                                    headers={"x-apikey": settings.virustotal_api_key})
        if resp.status_code == 429:
            return {"error": "تجاوزت حد VirusTotal المجاني (4 طلبات في الدقيقة)"}
        resp.raise_for_status()
        attrs = resp.json()["data"]["attributes"]
    except (httpx.HTTPError, KeyError, ValueError):
        return {"error": "تعذّر الحصول على نتيجة VirusTotal"}

    stats = attrs.get("last_analysis_stats", {})
    return {
        "malicious": stats.get("malicious", 0),
        "suspicious": stats.get("suspicious", 0),
        "harmless": stats.get("harmless", 0),
        "undetected": stats.get("undetected", 0),
        "reputation": attrs.get("reputation", 0),
        "permalink": f"https://www.virustotal.com/gui/domain/{domain}",
    }


def _virustotal_check(result: dict | None) -> Check:
    title = "فحص VirusTotal"
    if result is None:
        return Check(id="virustotal", title=title, status="info", message="غير مفعّل — أضف VIRUSTOTAL_API_KEY لتفعيله")
    if "error" in result:
        return Check(id="virustotal", title=title, status="info", message=result["error"])

    malicious, suspicious = result["malicious"], result["suspicious"]
    total = malicious + suspicious + result["harmless"] + result["undetected"]
    if malicious >= 2:
        status, msg = "fail", f"{malicious} محرك أمني من {total} صنّف النطاق خبيثاً"
    elif malicious == 1 or suspicious > 0:
        status, msg = "warn", f"{malicious} محرك صنّفه خبيثاً و{suspicious} مشبوهاً من {total} — قد يكون إنذاراً كاذباً"
    else:
        status, msg = "pass", f"لم يرصده أي من {total} محرك أمني"
    return Check(id="virustotal", title=title, status=status, message=msg, value=result["permalink"])


# ---------------------------------------------------------------- Domain age
async def _fetch_domain_info(domain: str) -> dict:
    """بيانات تسجيل النطاق عبر RDAP (البديل الحديث لـ WHOIS)."""
    info: dict = {"name": domain, "available": False, "created_at": None, "age_days": None, "registrar": None}
    if _is_ip(domain):
        return info
    try:
        async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
            resp = await client.get(RDAP_ENDPOINT.format(domain=domain), headers={"Accept": "application/rdap+json"})
        if resp.status_code != 200:
            return info
        data = resp.json()
    except (httpx.HTTPError, ValueError):
        return info

    info["available"] = True
    for event in data.get("events", []):
        if event.get("eventAction") == "registration":
            info["created_at"] = event.get("eventDate")
    for entity in data.get("entities", []):
        if "registrar" in entity.get("roles", []):
            vcard = entity.get("vcardArray", [None, []])
            for item in (vcard[1] if len(vcard) > 1 else []):
                if isinstance(item, list) and item and item[0] == "fn":
                    info["registrar"] = item[3]
    if info["created_at"]:
        try:
            created = datetime.fromisoformat(info["created_at"].replace("Z", "+00:00"))
            info["age_days"] = (datetime.now(timezone.utc) - created).days
        except ValueError:
            pass
    return info


def _domain_age_check(info: dict) -> Check:
    title = "عمر النطاق"
    age = info.get("age_days")
    if age is None:
        return Check(id="domain_age", title=title, status="info",
                     message="تعذّر معرفة تاريخ التسجيل (بعض الامتدادات مثل .sa لا توفره)")
    years = age / 365
    if age < 30:
        return Check(id="domain_age", title=title, status="fail", value=age,
                     message=f"سُجّل قبل {age} يوماً فقط — أغلب مواقع التصيّد عمرها أقل من شهر")
    if age < 180:
        return Check(id="domain_age", title=title, status="warn", value=age,
                     message=f"نطاق حديث ({age} يوماً) — تعامل بحذر إن طلب بيانات حساسة")
    label = f"{years:.0f} سنة" if years >= 1 else f"{age} يوماً"
    return Check(id="domain_age", title=title, status="pass", value=age, message=f"نطاق قديم ومستقر (عمره {label})")


# ---------------------------------------------------------------- Page indicators
def _page_checks(snap: PageSnapshot) -> list[Check]:
    soup = snap.soup
    base = registrable_domain(snap.host)

    def external_domain(url: str) -> str | None:
        """يعيد النطاق الأساسي للرابط إن كان خارجياً، وإلا None."""
        target = urlparse(urljoin(snap.final_url, url)).hostname
        if not target:
            return None
        target_base = registrable_domain(target)
        return target_base if target_base != base else None

    inline_js = "\n".join(s.get_text() for s in soup.find_all("script") if not s.get("src"))[:1_000_000]
    html = snap.html[:1_500_000]
    checks: list[Check] = []

    # 1) نماذج ترسل كلمات المرور لنطاق آخر — أقوى مؤشر على التصيّد
    leaking_forms = []
    for form in soup.find_all("form"):
        if form.find("input", attrs={"type": "password"}):
            target = external_domain(form.get("action") or "")
            if target:
                leaking_forms.append(target)
    if leaking_forms:
        checks.append(Check(id="phishing_form", title="نماذج كلمات المرور", status="fail", value=leaking_forms,
                            message=f"نموذج دخول يرسل كلمة المرور إلى نطاق آخر ({leaking_forms[0]}) — نمط تصيّد شائع"))
    else:
        checks.append(Check(id="phishing_form", title="نماذج كلمات المرور", status="pass",
                            message="لا توجد نماذج ترسل كلمات المرور لنطاقات خارجية"))

    # 2) انتحال علامة تجارية: صفحة دخول تحمل اسم جهة معروفة على نطاق لا يخصها
    has_password = soup.find("input", attrs={"type": "password"}) is not None
    headline = " ".join(filter(None, [
        soup.title.get_text(" ", strip=True) if soup.title else "",
        *(h.get_text(" ", strip=True) for h in soup.find_all("h1")[:3]),
    ])).lower()
    impersonated = [
        brand for brand, keywords, real_domains in BRANDS
        if has_password and any(k in headline for k in keywords)
        and not any(d in snap.host.lower() for d in real_domains)
    ]
    if impersonated:
        checks.append(Check(id="impersonation", title="انتحال علامة تجارية", status="warn", value=impersonated,
                            message=f"صفحة دخول تحمل اسم «{impersonated[0]}» لكنها على نطاق لا يخصها — تحقق قبل إدخال أي بيانات"))
    elif has_password:
        checks.append(Check(id="impersonation", title="انتحال علامة تجارية", status="pass",
                            message="صفحة الدخول لا تنتحل علامة تجارية معروفة"))

    # 3) سكربتات تعدين العملات الرقمية (تستهلك جهاز الزائر خفية)
    miners = [p.replace("\\", "") for p in CRYPTO_MINERS if re.search(p, html, re.I)]
    checks.append(Check(
        id="crypto_miner", title="تعدين العملات الرقمية", status="fail" if miners else "pass", value=miners or None,
        message=f"سكربت تعدين مكتشف ({miners[0]}) يستهلك جهاز الزائر دون علمه" if miners else "لا توجد سكربتات تعدين",
    ))

    # 4) كود JavaScript مشوّش (Obfuscated) — يُستخدم لإخفاء الكود الخبيث
    obfuscation = [label for pattern, label in OBFUSCATION_PATTERNS if re.search(pattern, inline_js, re.I)]
    checks.append(Check(
        id="obfuscated_js", title="كود JavaScript مشوّش", status="warn" if obfuscation else "pass", value=obfuscation or None,
        message=f"أنماط إخفاء مكتشفة: {'، '.join(obfuscation)}" if obfuscation else "لا توجد أنماط تشويش معروفة",
    ))

    # 5) iframes مخفية تحمّل محتوى من نطاقات أخرى
    hidden_frames = []
    for frame in soup.find_all("iframe"):
        src = frame.get("src") or ""
        style = (frame.get("style") or "").replace(" ", "").lower()
        hidden = (frame.get("width") in ("0", "1") or frame.get("height") in ("0", "1")
                  or "display:none" in style or "visibility:hidden" in style)
        target = external_domain(src) if src else None
        if hidden and target and target not in TRUSTED_HIDDEN_FRAMES:
            hidden_frames.append(src)
    checks.append(Check(
        id="hidden_iframes", title="إطارات مخفية (iframe)", status="warn" if hidden_frames else "pass",
        value=hidden_frames[:5] or None,
        message=f"{len(hidden_frames)} إطار مخفي يحمّل محتوى من نطاق آخر" if hidden_frames else "لا توجد إطارات مخفية مشبوهة",
    ))

    # 6) تحويل تلقائي لنطاق آخر (meta refresh أو JavaScript)
    redirects = []
    for meta in soup.find_all("meta", attrs={"http-equiv": re.compile("^refresh$", re.I)}):
        match = re.search(r"url\s*=\s*['\"]?([^'\";]+)", meta.get("content") or "", re.I)
        if match and external_domain(match.group(1)):
            redirects.append(match.group(1))
    for match in re.finditer(r"(?:window\.|document\.)?location(?:\.href)?\s*(?:=|\.replace\(|\.assign\()\s*['\"](https?://[^'\"]+)", inline_js):
        if external_domain(match.group(1)):
            redirects.append(match.group(1))
    checks.append(Check(
        id="external_redirect", title="تحويل تلقائي لموقع آخر", status="warn" if redirects else "pass",
        value=redirects[:5] or None,
        message=f"الصفحة تحوّل الزائر تلقائياً إلى {external_domain(redirects[0])}" if redirects else "لا يوجد تحويل تلقائي لنطاقات أخرى",
    ))
    return checks


def _url_checks(host: str) -> list[Check]:
    checks: list[Check] = []

    # نطاقات Punycode قد تُستخدم لتقليد نطاقات حقيقية بحروف متشابهة (مثل аpple بحرف روسي)
    if "xn--" in host:
        checks.append(Check(id="idn_homograph", title="نطاق بحروف دولية", status="warn",
                            message="النطاق يستخدم حروفاً دولية (Punycode) قد تُقلّد نطاقاً معروفاً بصرياً"))

    if _is_ip(host):
        checks.append(Check(id="ip_host", title="الوصول عبر عنوان IP", status="warn",
                            message="الموقع يُفتح بعنوان IP مباشر بدل اسم نطاق — نادر في المواقع الموثوقة"))

    tld = host.rsplit(".", 1)[-1].lower()
    if tld in RISKY_TLDS:
        checks.append(Check(id="risky_tld", title="امتداد النطاق", status="warn",
                            message=f"الامتداد .{tld} يكثر استخدامه في المواقع الاحتيالية (مؤشر ضعيف وحده)"))
    return checks
