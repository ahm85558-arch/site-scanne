"""
فحص الأمان (Security Analysis)
==============================
الفحوصات هنا سلبية (Passive) في معظمها: نقرأ ما يرسله الخادم دون محاولة استغلال أي ثغرة.
الاستثناء الوحيد طلب GET عادي لملفين حساسين شائعَي التسريب (.git و .env).
⚠️ افحص فقط المواقع التي تملكها أو لديك إذن صريح بفحصها.
"""
from __future__ import annotations

import asyncio
import re
import socket
import ssl
from datetime import datetime, timezone

import httpx

from app.models import Check, SectionResult
from app.services.snapshot import PageSnapshot
from app.utils.scoring import score_checks
from app.utils.url_guard import UnsafeURLError

# أوزان الفحوصات: الأخطر يؤثر أكثر على الدرجة النهائية
WEIGHTS: dict[str, float] = {
    "https": 3, "ssl_certificate": 3, "tls_version": 2, "http_redirect": 1.5,
    "hsts": 2, "csp": 2, "clickjacking": 1.5, "nosniff": 1,
    "referrer_policy": 0.5, "permissions_policy": 0.5, "cors": 2,
    "info_disclosure": 1, "cookies": 1.5, "mixed_content": 2,
    "insecure_forms": 2, "outdated_libraries": 1.5, "exposed_files": 3,
}

# الترويسات التي نعرضها في جدول لوحة التحكم
DISPLAY_HEADERS = [
    "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
    "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy",
    "Cross-Origin-Opener-Policy", "Cross-Origin-Resource-Policy",
]

# مكتبات JavaScript بإصدارات قديمة لها ثغرات معروفة: (الاسم، نمط الإصدار، أقل إصدار آمن، السبب)
VULNERABLE_LIBRARIES = [
    ("jQuery", r"jquery[.\-/@]v?(\d+\.\d+\.\d+)", (3, 5, 0), "ثغرات XSS معروفة (CVE-2020-11022)"),
    ("Bootstrap", r"bootstrap[.\-/@]v?(\d+\.\d+\.\d+)", (3, 4, 1), "ثغرة XSS معروفة (CVE-2019-8331)"),
    ("Lodash", r"lodash[.\-/@]v?(\d+\.\d+\.\d+)", (4, 17, 21), "ثغرات Prototype Pollution"),
    ("AngularJS", r"angular(?:js)?[.\-/@]v?(1\.\d+\.\d+)", (2, 0, 0), "إطار منتهي الدعم منذ 2022"),
]

# ملفات حساسة إن كانت مكشوفة فهي ثغرة خطيرة. نتحقق من المحتوى لتجنب الإيجابيات الكاذبة.
SENSITIVE_FILES = [
    ("/.git/HEAD", re.compile(r"^ref:\s*refs/", re.M), "مستودع Git مكشوف (قد يُسرّب الكود المصدري)"),
    ("/.env", re.compile(r"^[A-Z][A-Z0-9_]*=", re.M), "ملف .env مكشوف (قد يحتوي كلمات مرور ومفاتيح)"),
]


async def scan_security(snap: PageSnapshot, client: httpx.AsyncClient) -> SectionResult:
    checks: list[Check] = []

    # 1) HTTPS وشهادة SSL
    ssl_info: dict | None = None
    if snap.is_https:
        ssl_info = await asyncio.to_thread(_get_certificate_info, snap.host)
        checks.append(Check(id="https", title="استخدام HTTPS", status="pass", message="الاتصال بالموقع مشفّر"))
        checks += _ssl_checks(ssl_info)
    else:
        checks.append(Check(id="https", title="استخدام HTTPS", status="fail",
                            message="الموقع لا يستخدم HTTPS — البيانات تُنقل بدون تشفير"))

    # 2) بقية الفحوصات الشبكية تعمل بالتوازي لتسريع الفحص
    redirect_check, cors_check, exposed_check, sectxt_check = await asyncio.gather(
        _check_http_redirect(snap, client),
        _check_cors(snap, client),
        _check_exposed_files(snap, client),
        _check_security_txt(snap, client),
    )
    checks.append(redirect_check)

    # 3) الترويسات الأمنية
    header_rows, header_checks = _check_security_headers(snap.headers, snap.is_https)
    checks += header_checks
    checks.append(cors_check)

    # 4) فحوصات المحتوى (بدون طلبات إضافية)
    checks.append(_check_info_disclosure(snap.headers))
    checks.append(_check_cookies(snap.set_cookies))
    if snap.is_https:
        checks.append(_check_mixed_content(snap))
    checks.append(_check_insecure_forms(snap))
    checks.append(_check_outdated_libraries(snap))
    checks.append(exposed_check)
    checks.append(sectxt_check)

    return SectionResult(
        score=score_checks(checks, WEIGHTS),
        checks=checks,
        data={"ssl": ssl_info, "headers": header_rows},
    )


# ---------------------------------------------------------------- SSL / TLS
def _rdn_to_dict(rdn_seq) -> dict[str, str]:
    """تحويل صيغة issuer/subject من مكتبة ssl إلى قاموس بسيط."""
    return {key: value for rdn in rdn_seq for (key, value) in rdn}


def _get_certificate_info(host: str, port: int = 443) -> dict:
    """الاتصال المباشر بالمنفذ 443 وقراءة تفاصيل الشهادة وإصدار TLS."""
    context = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=8) as sock:
            with context.wrap_socket(sock, server_hostname=host) as tls:
                cert = tls.getpeercert()
                tls_version = tls.version()
    except ssl.SSLCertVerificationError as exc:
        return {"valid": False, "error": exc.verify_message or str(exc)}
    except (OSError, ssl.SSLError) as exc:
        return {"valid": False, "error": str(exc)}

    expires = datetime.fromtimestamp(ssl.cert_time_to_seconds(cert["notAfter"]), tz=timezone.utc)
    issued = datetime.fromtimestamp(ssl.cert_time_to_seconds(cert["notBefore"]), tz=timezone.utc)
    issuer = _rdn_to_dict(cert.get("issuer", ()))
    subject = _rdn_to_dict(cert.get("subject", ()))
    san = [value for kind, value in cert.get("subjectAltName", ()) if kind == "DNS"]

    return {
        "valid": True,
        "issuer": issuer.get("organizationName") or issuer.get("commonName"),
        "subject": subject.get("commonName"),
        "issued_at": issued.isoformat(),
        "expires_at": expires.isoformat(),
        "days_left": (expires - datetime.now(timezone.utc)).days,
        "tls_version": tls_version,
        "san": san[:10],
    }


def _ssl_checks(info: dict) -> list[Check]:
    if not info.get("valid"):
        return [Check(id="ssl_certificate", title="شهادة SSL", status="fail",
                      message=f"الشهادة غير صالحة: {info.get('error', 'سبب غير معروف')}")]

    days = info["days_left"]
    if days < 0:
        status, msg = "fail", "الشهادة منتهية الصلاحية"
    elif days < 15:
        status, msg = "warn", f"الشهادة تنتهي خلال {days} يوماً — جدّدها قريباً"
    else:
        status, msg = "pass", f"صالحة، صادرة من {info.get('issuer') or 'جهة غير معروفة'}، متبقٍ {days} يوماً"
    checks = [Check(id="ssl_certificate", title="شهادة SSL", status=status, message=msg, value=info["expires_at"])]

    tls = info.get("tls_version") or ""
    if tls == "TLSv1.3":
        checks.append(Check(id="tls_version", title="إصدار TLS", status="pass", message="يدعم TLS 1.3 (الأحدث)", value=tls))
    elif tls == "TLSv1.2":
        checks.append(Check(id="tls_version", title="إصدار TLS", status="pass",
                            message="TLS 1.2 مقبول، ويُفضّل تفعيل TLS 1.3", value=tls))
    else:
        checks.append(Check(id="tls_version", title="إصدار TLS", status="fail",
                            message=f"بروتوكول قديم وغير آمن: {tls or 'غير معروف'}", value=tls))
    return checks


async def _check_http_redirect(snap: PageSnapshot, client: httpx.AsyncClient) -> Check:
    """هل نسخة http:// تحوّل الزائر تلقائياً إلى https://؟"""
    title = "تحويل HTTP إلى HTTPS"
    if not snap.is_https:
        return Check(id="http_redirect", title=title, status="fail", message="لا يوجد إصدار HTTPS للتحويل إليه")
    try:
        resp = await client.get(f"http://{snap.host}/", follow_redirects=False)
    except (httpx.HTTPError, UnsafeURLError):
        return Check(id="http_redirect", title=title, status="info", message="المنفذ 80 مغلق — لا يمكن الوصول عبر HTTP أصلاً")

    location = resp.headers.get("location", "")
    if resp.is_redirect and location.startswith("https://"):
        return Check(id="http_redirect", title=title, status="pass",
                     message=f"يحوّل تلقائياً ({resp.status_code}) إلى النسخة المشفّرة")
    return Check(id="http_redirect", title=title, status="fail",
                 message="نسخة HTTP تعمل دون تحويل إلى HTTPS")


# ---------------------------------------------------------------- Headers
def _check_security_headers(headers: httpx.Headers, is_https: bool) -> tuple[list[dict], list[Check]]:
    checks: list[Check] = []

    # Strict-Transport-Security: يُلزم المتصفح باستخدام HTTPS دائماً
    hsts = headers.get("strict-transport-security")
    title = "ترويسة HSTS"
    if not is_https:
        checks.append(Check(id="hsts", title=title, status="info", message="لا تنطبق على المواقع غير المشفّرة"))
    elif not hsts:
        checks.append(Check(id="hsts", title=title, status="fail",
                            message="مفقودة — قد يتصل المتصفح بالموقع عبر HTTP غير المشفّر"))
    else:
        match = re.search(r"max-age=(\d+)", hsts, re.I)
        max_age = int(match.group(1)) if match else 0
        if max_age >= 15_552_000:  # 6 أشهر
            extra = " مع includeSubDomains" if "includesubdomains" in hsts.lower() else ""
            checks.append(Check(id="hsts", title=title, status="pass", message=f"مفعّلة{extra}", value=hsts))
        else:
            checks.append(Check(id="hsts", title=title, status="warn",
                                message="مدة max-age قصيرة — يُنصح بستة أشهر على الأقل (15552000)", value=hsts))

    # Content-Security-Policy: أقوى حماية ضد XSS
    csp = headers.get("content-security-policy")
    title = "سياسة أمان المحتوى (CSP)"
    if not csp:
        checks.append(Check(id="csp", title=title, status="fail",
                            message="مفقودة — CSP هي خط الدفاع الأقوى ضد هجمات XSS وحقن السكربتات"))
    elif "'unsafe-inline'" in csp or "'unsafe-eval'" in csp:
        checks.append(Check(id="csp", title=title, status="warn",
                            message="موجودة لكنها تسمح بـ unsafe-inline أو unsafe-eval مما يُضعف الحماية", value=csp))
    else:
        checks.append(Check(id="csp", title=title, status="pass", message="مفعّلة بشكل جيد", value=csp))

    # الحماية من Clickjacking عبر X-Frame-Options أو frame-ancestors
    xfo = (headers.get("x-frame-options") or "").strip().upper()
    title = "الحماية من Clickjacking"
    if xfo in ("DENY", "SAMEORIGIN"):
        checks.append(Check(id="clickjacking", title=title, status="pass", message=f"X-Frame-Options: {xfo}"))
    elif csp and "frame-ancestors" in csp:
        checks.append(Check(id="clickjacking", title=title, status="pass", message="محمي عبر frame-ancestors في CSP"))
    else:
        checks.append(Check(id="clickjacking", title=title, status="warn",
                            message="يمكن تضمين الموقع داخل iframe في مواقع أخرى"))

    # X-Content-Type-Options
    nosniff = (headers.get("x-content-type-options") or "").lower()
    checks.append(Check(
        id="nosniff", title="ترويسة X-Content-Type-Options",
        status="pass" if nosniff == "nosniff" else "warn",
        message="مفعّلة (nosniff)" if nosniff == "nosniff" else "مفقودة — المتصفح قد يخمّن نوع الملفات بشكل خاطئ",
    ))

    # Referrer-Policy
    referrer = headers.get("referrer-policy")
    if not referrer:
        status, msg = "warn", "مفقودة — قد تتسرب روابط الصفحات كاملة إلى المواقع الخارجية"
    elif "unsafe-url" in referrer.lower():
        status, msg = "warn", "القيمة unsafe-url ترسل الرابط الكامل لأي موقع"
    else:
        status, msg = "pass", f"مضبوطة: {referrer}"
    checks.append(Check(id="referrer_policy", title="ترويسة Referrer-Policy", status=status, message=msg))

    # Permissions-Policy
    permissions = headers.get("permissions-policy")
    checks.append(Check(
        id="permissions_policy", title="ترويسة Permissions-Policy",
        status="pass" if permissions else "warn",
        message="مضبوطة" if permissions else "مفقودة — لا يوجد تقييد لصلاحيات الكاميرا والموقع وغيرها",
    ))

    rows = [{"name": name, "present": headers.get(name) is not None, "value": headers.get(name)}
            for name in DISPLAY_HEADERS]
    return rows, checks


async def _check_cors(snap: PageSnapshot, client: httpx.AsyncClient) -> Check:
    """
    نرسل الطلب مع Origin وهمي: إن أعاده الخادم في Access-Control-Allow-Origin
    فهو يثق بأي موقع — وهذا خطير جداً إن صاحبه Allow-Credentials.
    """
    title = "سياسة CORS"
    probe_origin = "https://cors-probe.example"
    try:
        resp = await client.get(snap.final_url, headers={"Origin": probe_origin})
    except (httpx.HTTPError, UnsafeURLError):
        return Check(id="cors", title=title, status="info", message="تعذّر اختبار CORS")

    allow_origin = resp.headers.get("access-control-allow-origin")
    credentials = resp.headers.get("access-control-allow-credentials", "").lower() == "true"

    if allow_origin == probe_origin and credentials:
        return Check(id="cors", title=title, status="fail", value=allow_origin,
                     message="يقبل أي Origin مع السماح بالـ Credentials — يمكن لموقع خبيث قراءة بيانات المستخدمين")
    if allow_origin == probe_origin:
        return Check(id="cors", title=title, status="warn", value=allow_origin,
                     message="يعكس أي Origin يُرسل إليه — يُفضّل استخدام قائمة نطاقات محددة")
    if allow_origin == "*":
        return Check(id="cors", title=title, status="warn", value=allow_origin,
                     message="مفتوحة للجميع (*) — مقبول فقط للمحتوى العام")
    if allow_origin:
        return Check(id="cors", title=title, status="pass", value=allow_origin, message=f"مقيّدة بـ {allow_origin}")
    return Check(id="cors", title=title, status="pass", message="لا توجد سياسة CORS مفتوحة")


# ---------------------------------------------------------------- Content checks
def _check_info_disclosure(headers: httpx.Headers) -> Check:
    """الترويسات التي تكشف نوع الخادم وإصداره تسهّل على المهاجم البحث عن ثغرات."""
    leaks = []
    server = headers.get("server", "")
    if re.search(r"\d", server):
        leaks.append(f"Server: {server}")
    for name in ("x-powered-by", "x-aspnet-version", "x-aspnetmvc-version"):
        if headers.get(name):
            leaks.append(f"{name}: {headers[name]}")

    if leaks:
        return Check(id="info_disclosure", title="كشف معلومات الخادم", status="warn", value=leaks,
                     message="الخادم يكشف تفاصيل تقنية وإصدارات: " + "، ".join(leaks))
    return Check(id="info_disclosure", title="كشف معلومات الخادم", status="pass",
                 message="لا تُكشف إصدارات البرمجيات في الترويسات")


def _check_cookies(set_cookies: list[str]) -> Check:
    title = "أمان الكوكيز"
    if not set_cookies:
        return Check(id="cookies", title=title, status="info", message="الصفحة لا تضبط أي كوكيز")

    issues = []
    for raw in set_cookies:
        name = raw.split("=", 1)[0].strip()
        attributes = {part.strip().split("=", 1)[0].lower() for part in raw.split(";")[1:]}
        missing = [flag for flag in ("secure", "httponly", "samesite") if flag not in attributes]
        if missing:
            issues.append(f"{name} (ينقصه: {', '.join(missing)})")

    if not issues:
        return Check(id="cookies", title=title, status="pass", message="كل الكوكيز تستخدم Secure و HttpOnly و SameSite")
    return Check(id="cookies", title=title, status="warn", value=issues,
                 message=f"{len(issues)} من {len(set_cookies)} كوكيز تنقصها خصائص أمان")


def _check_mixed_content(snap: PageSnapshot) -> Check:
    """موارد تُحمَّل عبر http:// داخل صفحة https:// تكسر التشفير."""
    found: list[str] = []
    for tag, attr in (("script", "src"), ("img", "src"), ("iframe", "src"),
                      ("source", "src"), ("video", "src"), ("audio", "src"), ("link", "href")):
        for element in snap.soup.find_all(tag):
            value = (element.get(attr) or "").strip()
            if not value.lower().startswith("http://"):
                continue
            if tag == "link":
                rel = {r.lower() for r in element.get("rel", [])}
                if not rel & {"stylesheet", "icon", "preload"}:
                    continue  # روابط canonical/alternate ليست محتوى مختلطاً
            found.append(value)

    if not found:
        return Check(id="mixed_content", title="المحتوى المختلط", status="pass",
                     message="كل الموارد تُحمَّل عبر HTTPS")
    return Check(id="mixed_content", title="المحتوى المختلط", status="fail", value=found[:10],
                 message=f"{len(found)} مورد يُحمَّل عبر HTTP غير المشفّر داخل صفحة مشفّرة")


def _check_insecure_forms(snap: PageSnapshot) -> Check:
    title = "النماذج (Forms)"
    forms = snap.soup.find_all("form")
    if not forms:
        return Check(id="insecure_forms", title=title, status="info", message="لا توجد نماذج في الصفحة")

    insecure = [f.get("action") or "(نفس الصفحة)" for f in forms
                if (f.get("action") or "").lower().startswith("http://")]
    has_password = snap.soup.find("input", attrs={"type": "password"}) is not None
    if not snap.is_https and has_password:
        return Check(id="insecure_forms", title=title, status="fail",
                     message="حقل كلمة مرور في صفحة غير مشفّرة — كلمات المرور تُرسل كنص واضح")
    if insecure:
        return Check(id="insecure_forms", title=title, status="fail", value=insecure,
                     message=f"{len(insecure)} نموذج يرسل البيانات عبر HTTP غير المشفّر")
    return Check(id="insecure_forms", title=title, status="pass", message="كل النماذج ترسل البيانات بشكل آمن")


def _parse_version(text: str) -> tuple[int, ...]:
    return tuple(int(part) for part in text.split(".")[:3])


def _check_outdated_libraries(snap: PageSnapshot) -> Check:
    sources = " ".join(
        (el.get("src") or el.get("href") or "")
        for el in snap.soup.find_all(["script", "link"])
    )
    findings = []
    for name, pattern, safe_version, reason in VULNERABLE_LIBRARIES:
        for version in set(re.findall(pattern, sources, re.I)):
            if _parse_version(version) < safe_version:
                findings.append(f"{name} {version}: {reason}")

    if findings:
        return Check(id="outdated_libraries", title="مكتبات JavaScript قديمة", status="fail", value=findings,
                     message=f"{len(findings)} مكتبة بإصدار له ثغرات معروفة — حدّثها")
    return Check(id="outdated_libraries", title="مكتبات JavaScript قديمة", status="pass",
                 message="لم نكتشف مكتبات بإصدارات معروفة الثغرات")


async def _check_exposed_files(snap: PageSnapshot, client: httpx.AsyncClient) -> Check:
    async def probe(path: str, signature: re.Pattern, reason: str) -> str | None:
        try:
            resp = await client.get(snap.origin + path, follow_redirects=False)
        except (httpx.HTTPError, UnsafeURLError):
            return None
        if resp.status_code == 200 and signature.search(resp.text[:2000]):
            return f"{path}: {reason}"
        return None

    results = await asyncio.gather(*(probe(*item) for item in SENSITIVE_FILES))
    exposed = [r for r in results if r]
    if exposed:
        return Check(id="exposed_files", title="ملفات حساسة مكشوفة", status="fail", value=exposed,
                     message="تم العثور على ملفات حساسة متاحة للعامة — احجبها فوراً")
    return Check(id="exposed_files", title="ملفات حساسة مكشوفة", status="pass",
                 message="ملفات .git و .env غير مكشوفة")


async def _check_security_txt(snap: PageSnapshot, client: httpx.AsyncClient) -> Check:
    """ملف security.txt يخبر الباحثين الأمنيين بكيفية الإبلاغ عن الثغرات (RFC 9116)."""
    try:
        resp = await client.get(snap.origin + "/.well-known/security.txt")
        found = resp.status_code == 200 and "contact:" in resp.text.lower()
    except (httpx.HTTPError, UnsafeURLError):
        found = False
    return Check(
        id="security_txt", title="ملف security.txt", status="pass" if found else "info",
        message="موجود ويحدد جهة الإبلاغ عن الثغرات" if found else "غير موجود (اختياري لكنه ممارسة جيدة)",
    )
