"""
فحص الأداء (Performance & Speed)
================================
- قياسات مباشرة من خادمنا: TTFB، حجم HTML، الضغط، HTTP/2، عدد الموارد وحجمها.
- مؤشرات Core Web Vitals (LCP, CLS, TBT, INP...) عبر Google PageSpeed Insights API،
  لأن قياسها الحقيقي يتطلب متصفحاً كاملاً (Lighthouse) لا مجرد طلب HTTP.
"""
from __future__ import annotations

import asyncio
from urllib.parse import urljoin

import httpx

from app.config import settings
from app.models import Check, SectionResult
from app.services.snapshot import PageSnapshot
from app.utils.scoring import rate, score_checks
from app.utils.url_guard import UnsafeURLError

PSI_ENDPOINT = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed"

WEIGHTS = {"ttfb": 2, "page_weight": 2, "compression": 1.5, "render_blocking": 1.5,
           "lcp": 3, "cls": 2, "tbt": 2, "inp": 2}


async def scan_performance(snap: PageSnapshot, client: httpx.AsyncClient) -> SectionResult:
    # قياس الموارد وطلب PageSpeed يعملان بالتوازي (PageSpeed هو الأبطأ)
    resources, (vitals, vitals_error) = await asyncio.gather(
        _measure_resources(snap, client),
        _fetch_pagespeed(snap.final_url),
    )

    checks: list[Check] = []

    # 1) زمن الاستجابة الأولي (TTFB) — حدود Google: جيد ≤ 800ms
    checks.append(Check(
        id="ttfb", title="زمن الاستجابة الأولي (TTFB)", status=rate(snap.ttfb_ms, 800, 1800), value=snap.ttfb_ms,
        message=f"وصل أول بايت بعد {snap.ttfb_ms} ms" + (" — سريع" if snap.ttfb_ms <= 800 else " — الخادم بطيء في الرد"),
    ))

    # 2) حجم مستند HTML
    kb = snap.html_bytes / 1024
    checks.append(Check(id="html_size", title="حجم مستند HTML", status=rate(kb, 100, 500), value=snap.html_bytes,
                        message=f"{kb:.0f} KB" + (" — مناسب" if kb <= 100 else " — كبير، قلّل الكود المضمّن")))

    # 3) الضغط
    encoding = snap.headers.get("content-encoding")
    compressed = (encoding or "").lower() in ("gzip", "br", "zstd", "deflate")
    checks.append(Check(id="compression", title="ضغط الاستجابة", status="pass" if compressed else "warn", value=encoding,
                        message=f"مفعّل ({encoding})" if compressed else "غير مفعّل — فعّل Brotli أو Gzip لتقليل الحجم 70%"))

    # 4) إصدار بروتوكول HTTP
    modern = snap.http_version in ("HTTP/2", "HTTP/3")
    has_h3 = "h3" in snap.headers.get("alt-svc", "")
    checks.append(Check(id="http_version", title="بروتوكول HTTP", status="pass" if modern else "warn",
                        value=snap.http_version,
                        message=f"{snap.http_version}" + (" + يعلن دعم HTTP/3" if has_h3 else "")
                        + ("" if modern else " — فعّل HTTP/2 لتحميل الموارد بالتوازي")))

    # 5) الوزن الكلي للصفحة (تقديري)
    weight_mb = resources["page_weight_bytes"] / 1024 / 1024
    checks.append(Check(id="page_weight", title="الوزن الكلي للصفحة", status=rate(weight_mb, 2, 5),
                        value=resources["page_weight_bytes"],
                        message=f"قرابة {weight_mb:.1f} MB (تقدير من {resources['measured']} مورد)"))

    # 6) عدد الطلبات
    request_count = sum(resources[k]["count"] for k in ("scripts", "stylesheets", "images"))
    checks.append(Check(id="request_count", title="عدد الموارد", status=rate(request_count, 50, 100), value=request_count,
                        message=f"{request_count} مورد (سكربتات، تنسيقات، صور)"))

    # 7) السكربتات التي تحجب العرض
    blocking = _count_render_blocking(snap)
    checks.append(Check(id="render_blocking", title="سكربتات تحجب العرض", status=rate(blocking, 0, 3), value=blocking,
                        message="لا توجد" if not blocking else f"{blocking} سكربت في <head> بدون async أو defer"))

    # 8) التحميل الكسول للصور
    images = snap.soup.find_all("img")
    lazy = sum(1 for img in images if (img.get("loading") or "").lower() == "lazy")
    if len(images) > 5:
        checks.append(Check(id="lazy_images", title="التحميل الكسول للصور", status="pass" if lazy else "warn",
                            message=f"{lazy} من {len(images)} صورة تستخدم loading=\"lazy\""))

    # 9) التخزين المؤقت للموارد
    if resources["measured"]:
        uncached = resources["uncached"]
        checks.append(Check(id="caching", title="التخزين المؤقت (Caching)",
                            status=rate(uncached / resources["measured"], 0.1, 0.4),
                            message=f"{uncached} من {resources['measured']} مورد بدون Cache-Control مناسب"))

    # 10) Core Web Vitals
    if vitals:
        checks += _vitals_checks(vitals)

    score = score_checks(checks, WEIGHTS)
    # إن توفرت درجة Lighthouse نمزجها مع فحوصاتنا لأنها أدق في قياس تجربة المستخدم
    if vitals and vitals.get("lighthouse_score") is not None:
        score = round(vitals["lighthouse_score"] * 0.6 + score * 0.4)

    return SectionResult(score=score, checks=checks, data={
        "ttfb_ms": snap.ttfb_ms,
        "total_ms": snap.total_ms,
        "html_bytes": snap.html_bytes,
        "page_weight_bytes": resources["page_weight_bytes"],
        "http_version": snap.http_version,
        "compression": encoding,
        "resources": {k: resources[k] for k in ("scripts", "stylesheets", "images", "measured", "uncached")},
        "web_vitals": vitals,
        "web_vitals_error": vitals_error,
    })


def _count_render_blocking(snap: PageSnapshot) -> int:
    head = snap.soup.head
    if not head:
        return 0
    return sum(
        1 for script in head.find_all("script", src=True)
        if not script.has_attr("async") and not script.has_attr("defer")
        and (script.get("type") or "").lower() != "module"
    )


async def _measure_resources(snap: PageSnapshot, client: httpx.AsyncClient) -> dict:
    """نجمع روابط الموارد ونقيس حجم عيّنة منها عبر HEAD (أو GET عند غياب Content-Length)."""
    collected: dict[str, str] = {}  # الرابط ← النوع

    def add(src: str | None, kind: str) -> None:
        if src and not src.startswith("data:"):
            url = urljoin(snap.final_url, src.strip())
            if url.startswith(("http://", "https://")):
                collected.setdefault(url, kind)

    for el in snap.soup.find_all("script", src=True):
        add(el["src"], "scripts")
    for el in snap.soup.find_all("link", href=True):
        if "stylesheet" in [r.lower() for r in el.get("rel", [])]:
            add(el["href"], "stylesheets")
    for el in snap.soup.find_all("img"):
        add(el.get("src") or el.get("data-src"), "images")

    buckets = {kind: {"count": 0, "bytes": 0} for kind in ("scripts", "stylesheets", "images")}
    for kind in collected.values():
        buckets[kind]["count"] += 1

    semaphore = asyncio.Semaphore(8)

    async def measure(url: str) -> tuple[int, bool] | None:
        async with semaphore:
            try:
                resp = await client.head(url)
                size = int(resp.headers.get("content-length") or 0)
                if not size and resp.status_code < 400:
                    # بعض الخوادم لا ترسل الحجم مع HEAD — نعدّ البايتات فعلياً (مضغوطة)
                    async with client.stream("GET", url) as stream:
                        async for chunk in stream.aiter_raw():
                            size += len(chunk)
                cache = resp.headers.get("cache-control", "").lower()
                cached = "max-age" in cache and "max-age=0" not in cache and "no-store" not in cache
                return size, cached
            except (httpx.HTTPError, UnsafeURLError, ValueError):
                return None

    sample = list(collected.items())[: settings.max_resources_to_measure]
    results = await asyncio.gather(*(measure(url) for url, _ in sample))

    measured = uncached = 0
    for (url, kind), result in zip(sample, results):
        if result is None:
            continue
        size, cached = result
        measured += 1
        uncached += 0 if cached else 1
        buckets[kind]["bytes"] += size

    total = snap.html_bytes + sum(b["bytes"] for b in buckets.values())
    return {**buckets, "measured": measured, "uncached": uncached, "page_weight_bytes": total}


# ---------------------------------------------------------------- Core Web Vitals
async def _fetch_pagespeed(url: str) -> tuple[dict | None, str | None]:
    """يستدعي PageSpeed Insights (Lighthouse على جهاز جوال) ويستخرج المؤشرات الأساسية."""
    params = {"url": url, "strategy": "mobile", "category": "performance"}
    if settings.pagespeed_api_key:
        params["key"] = settings.pagespeed_api_key

    try:
        async with httpx.AsyncClient(timeout=settings.pagespeed_timeout) as psi:
            resp = await psi.get(PSI_ENDPOINT, params=params)
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 429:
            return None, "تجاوزت حصة PageSpeed المجانية — أضف PAGESPEED_API_KEY في ملف .env"
        return None, f"PageSpeed لم يتمكن من تحليل الصفحة (رمز {exc.response.status_code})"
    except httpx.HTTPError:
        return None, "تعذّر الاتصال بخدمة PageSpeed Insights أو انتهت المهلة"

    lighthouse = data.get("lighthouseResult", {})
    audits = lighthouse.get("audits", {})

    def lab(key: str) -> float | None:
        return audits.get(key, {}).get("numericValue")

    # البيانات الميدانية (Field Data) من مستخدمين حقيقيين — تتوفر للمواقع ذات الزيارات العالية فقط
    metrics = data.get("loadingExperience", {}).get("metrics", {})

    def field(key: str) -> float | None:
        return metrics.get(key, {}).get("percentile")

    field_cls = field("CUMULATIVE_LAYOUT_SHIFT_SCORE")
    field_data = {
        "lcp_ms": field("LARGEST_CONTENTFUL_PAINT_MS"),
        "inp_ms": field("INTERACTION_TO_NEXT_PAINT"),
        "cls": field_cls / 100 if field_cls is not None else None,
    }
    perf_score = lighthouse.get("categories", {}).get("performance", {}).get("score")

    return {
        "strategy": "mobile",
        "lighthouse_score": round(perf_score * 100) if perf_score is not None else None,
        "lcp_ms": lab("largest-contentful-paint"),
        "cls": lab("cumulative-layout-shift"),
        "tbt_ms": lab("total-blocking-time"),
        "fcp_ms": lab("first-contentful-paint"),
        "si_ms": lab("speed-index"),
        "tti_ms": lab("interactive"),
        "field": field_data if any(v is not None for v in field_data.values()) else None,
    }, None


def _vitals_checks(v: dict) -> list[Check]:
    """تقييم المؤشرات وفق عتبات Google الرسمية (جيد / يحتاج تحسين / ضعيف)."""
    checks: list[Check] = []
    if v.get("lcp_ms") is not None:
        checks.append(Check(id="lcp", title="أكبر عنصر مرئي (LCP)", status=rate(v["lcp_ms"], 2500, 4000),
                            value=v["lcp_ms"], message=f"{v['lcp_ms'] / 1000:.2f} ثانية (الهدف ≤ 2.5)"))
    if v.get("cls") is not None:
        checks.append(Check(id="cls", title="ثبات التخطيط (CLS)", status=rate(v["cls"], 0.1, 0.25),
                            value=v["cls"], message=f"{v['cls']:.3f} (الهدف ≤ 0.1)"))
    if v.get("tbt_ms") is not None:
        checks.append(Check(id="tbt", title="زمن الحجب الكلي (TBT)", status=rate(v["tbt_ms"], 200, 600),
                            value=v["tbt_ms"], message=f"{v['tbt_ms']:.0f} ms (الهدف ≤ 200)"))
    inp = (v.get("field") or {}).get("inp_ms")
    if inp is not None:
        checks.append(Check(id="inp", title="الاستجابة للتفاعل (INP)", status=rate(inp, 200, 500),
                            value=inp, message=f"{inp:.0f} ms من مستخدمين حقيقيين (الهدف ≤ 200)"))
    return checks
