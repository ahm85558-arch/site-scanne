"""
اكتشاف التقنيات (Tech Stack Detection)
=====================================
نظام توقيعات مشابه لفكرة Wappalyzer: كل تقنية لها أنماط (Regex) نبحث عنها في
الترويسات، أسماء الكوكيز، محتوى HTML، روابط السكربتات/التنسيقات، ووسم generator.
لإضافة تقنية جديدة: أضف Signature واحداً إلى القائمة SIGNATURES.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.models import TechItem
from app.services.snapshot import PageSnapshot


@dataclass
class Signature:
    name: str
    category: str
    headers: dict[str, str] = field(default_factory=dict)  # اسم الترويسة ← نمط القيمة
    cookies: list[str] = field(default_factory=list)       # أنماط أسماء الكوكيز
    html: list[str] = field(default_factory=list)          # أنماط داخل HTML
    assets: list[str] = field(default_factory=list)        # أنماط روابط السكربتات والتنسيقات
    generator: str | None = None                           # نمط <meta name="generator">
    implies: list[str] = field(default_factory=list)       # تقنيات تُستنتج تلقائياً

# المجموعة الأولى من الأقواس () في أي نمط تُستخدم لاستخراج رقم الإصدار
SIGNATURES: list[Signature] = [
    # --- أنظمة إدارة المحتوى والمتاجر
    Signature("WordPress", "cms", html=[r"/wp-content/", r"/wp-includes/"], generator=r"WordPress\s*([\d.]+)?", implies=["PHP"]),
    Signature("Drupal", "cms", headers={"x-generator": r"Drupal\s*(\d+)?"}, generator=r"Drupal\s*(\d+)?", implies=["PHP"]),
    Signature("Joomla", "cms", generator=r"Joomla!?\s*([\d.]+)?", implies=["PHP"]),
    Signature("Ghost", "cms", generator=r"Ghost\s*([\d.]+)?", implies=["Node.js"]),
    Signature("Wix", "cms", headers={"x-wix-request-id": r".+"}, html=[r"static\.wixstatic\.com"]),
    Signature("Squarespace", "cms", html=[r"static1\.squarespace\.com"]),
    Signature("Webflow", "cms", html=[r"data-wf-page="], generator=r"Webflow"),
    Signature("Shopify", "ecommerce", headers={"x-shopid": r".+"}, html=[r"cdn\.shopify\.com"]),
    Signature("WooCommerce", "ecommerce", html=[r"woocommerce"], implies=["WordPress"]),
    Signature("Magento", "ecommerce", html=[r"Mage\.Cookies", r"/static/version\d+/frontend/"], implies=["PHP"]),
    Signature("Salla", "ecommerce", html=[r"cdn\.salla\.(?:sa|network)"]),
    Signature("Zid", "ecommerce", html=[r"zid\.store", r"cdn\.zid\.sa"]),

    # --- إطارات العمل
    Signature("Next.js", "framework", headers={"x-powered-by": r"Next\.js\s*([\d.]+)?"},
              html=[r"__NEXT_DATA__", r"/_next/static/"], implies=["React"]),
    Signature("Nuxt", "framework", html=[r"__NUXT__", r"/_nuxt/"], implies=["Vue.js"]),
    Signature("Gatsby", "framework", html=[r"___gatsby"], generator=r"Gatsby\s*([\d.]+)?", implies=["React"]),
    Signature("Remix", "framework", html=[r"__remixContext"], implies=["React"]),
    Signature("Astro", "framework", html=[r"astro-island"], generator=r"Astro\s*v?([\d.]+)?"),
    Signature("SvelteKit", "framework", html=[r"__sveltekit"], implies=["Svelte"]),
    Signature("Angular", "framework", html=[r'ng-version="([\d.]+)"']),
    Signature("AngularJS", "framework", html=[r"\sng-app[=\s>]"], assets=[r"angular(?:js)?[.\-/@](1\.[\d.]+)"]),
    Signature("Laravel", "framework", cookies=[r"^laravel_session$"], implies=["PHP"]),
    Signature("Django", "framework", cookies=[r"^csrftoken$", r"^django_language$"], html=[r"csrfmiddlewaretoken"], implies=["Python"]),
    Signature("Ruby on Rails", "framework", html=[r'name="csrf-param" content="authenticity_token"'], implies=["Ruby"]),
    Signature("Express", "framework", headers={"x-powered-by": r"^Express$"}, implies=["Node.js"]),
    Signature("ASP.NET", "framework", headers={"x-aspnet-version": r"([\d.]+)", "x-powered-by": r"ASP\.NET"},
              cookies=[r"^ASP\.NET_SessionId$", r"^\.AspNetCore\."], html=[r"__VIEWSTATE"]),

    # --- مكتبات JavaScript والواجهة
    Signature("React", "js_library", html=[r"data-reactroot", r"_reactListening"], assets=[r"react(?:-dom)?[.\-/@]([\d]+\.[\d.]+)"]),
    Signature("Vue.js", "js_library", html=[r"data-v-[0-9a-f]{8}"], assets=[r"vue[.\-/@](\d+\.[\d.]+)", r"/vue(?:\.global|\.runtime)?(?:\.min)?\.js"]),
    Signature("Svelte", "js_library", html=[r'class="[^"]*svelte-[a-z0-9]{5,}']),
    Signature("jQuery", "js_library", assets=[r"jquery[.\-/@]v?(\d+\.\d+\.\d+)", r"jquery(?:\.min)?\.js"]),
    Signature("Alpine.js", "js_library", html=[r"\sx-data="], assets=[r"alpinejs"]),
    Signature("Bootstrap", "ui", assets=[r"bootstrap[.\-/@]v?(\d+\.\d+\.\d+)", r"bootstrap(?:\.min)?\.(?:css|js)"]),
    Signature("Tailwind CSS", "ui", html=[r"--tw-[a-z]"], assets=[r"tailwind"]),
    Signature("Font Awesome", "fonts", assets=[r"font-?awesome", r"kit\.fontawesome\.com"]),
    Signature("Google Fonts", "fonts", html=[r"fonts\.googleapis\.com"]),

    # --- لغات الخادم (أغلبها يُستنتج من غيرها)
    Signature("PHP", "backend", headers={"x-powered-by": r"PHP/?([\d.]+)?"}, cookies=[r"^PHPSESSID$"]),
    Signature("Node.js", "backend"),
    Signature("Python", "backend"),
    Signature("Ruby", "backend"),
    Signature("Java", "backend", cookies=[r"^JSESSIONID$"]),

    # --- خوادم الويب والاستضافة وشبكات CDN
    Signature("Nginx", "server", headers={"server": r"nginx/?([\d.]+)?"}),
    Signature("Apache", "server", headers={"server": r"Apache/?([\d.]+)?"}),
    Signature("Microsoft IIS", "server", headers={"server": r"Microsoft-IIS/?([\d.]+)?"}),
    Signature("LiteSpeed", "server", headers={"server": r"LiteSpeed"}),
    Signature("Cloudflare", "cdn", headers={"cf-ray": r".+", "server": r"cloudflare"}),
    Signature("Amazon CloudFront", "cdn", headers={"x-amz-cf-id": r".+", "via": r"CloudFront"}),
    Signature("Fastly", "cdn", headers={"x-fastly-request-id": r".+", "x-served-by": r"cache-"}),
    Signature("Akamai", "cdn", headers={"x-akamai-transformed": r".+"}),
    Signature("Vercel", "hosting", headers={"x-vercel-id": r".+", "server": r"Vercel"}),
    Signature("Netlify", "hosting", headers={"x-nf-request-id": r".+", "server": r"Netlify"}),
    Signature("GitHub Pages", "hosting", headers={"server": r"GitHub\.com"}),
    Signature("Render", "hosting", headers={"rndr-id": r".+"}),

    # --- أدوات التحليل والتسويق
    Signature("Google Analytics", "analytics", html=[r"google-analytics\.com/(?:analytics|ga)\.js", r"googletagmanager\.com/gtag/js"]),
    Signature("Google Tag Manager", "analytics", html=[r"googletagmanager\.com/gtm\.js", r"GTM-[A-Z0-9]{4,}"]),
    Signature("Microsoft Clarity", "analytics", html=[r"clarity\.ms/tag"]),
    Signature("Hotjar", "analytics", html=[r"static\.hotjar\.com"]),
    Signature("Mixpanel", "analytics", html=[r"cdn\.mxpnl\.com", r"mixpanel\.init"]),
    Signature("Segment", "analytics", html=[r"cdn\.segment\.com"]),
    Signature("Plausible", "analytics", html=[r"plausible\.io/js"]),
    Signature("Meta Pixel", "marketing", html=[r"connect\.facebook\.net/[^\"']*/fbevents\.js"]),
    Signature("TikTok Pixel", "marketing", html=[r"analytics\.tiktok\.com"]),
    Signature("Snap Pixel", "marketing", html=[r"sc-static\.net/scevent"]),
    Signature("Intercom", "widgets", html=[r"widget\.intercom\.io"]),

    # --- الدفع والحماية
    Signature("Stripe", "payments", html=[r"js\.stripe\.com"]),
    Signature("Moyasar", "payments", html=[r"cdn\.moyasar\.com"]),
    Signature("Google reCAPTCHA", "security", html=[r"google\.com/recaptcha", r"recaptcha/api\.js"]),
    Signature("hCaptcha", "security", html=[r"hcaptcha\.com/1/api\.js"]),
]

SIGNATURES_BY_NAME = {sig.name: sig for sig in SIGNATURES}


def _match(pattern: str, text: str) -> tuple[bool, str | None]:
    """يبحث عن النمط ويعيد (هل وُجد؟، الإصدار إن وُجد)."""
    m = re.search(pattern, text, re.I)
    if not m:
        return False, None
    version = m.group(1) if m.groups() and m.group(1) else None
    return True, version


def detect_tech_stack(snap: PageSnapshot) -> list[TechItem]:
    headers = {k.lower(): v for k, v in snap.headers.items()}
    cookie_names = [c.split("=", 1)[0].strip() for c in snap.set_cookies]
    html = snap.html[:600_000]  # نحدّ حجم النص لتسريع الـ Regex
    assets = "\n".join(
        el.get("src") or el.get("href") or "" for el in snap.soup.find_all(["script", "link"])
    )
    generator_tag = snap.soup.find("meta", attrs={"name": re.compile("^generator$", re.I)})
    generator = (generator_tag.get("content") or "") if generator_tag else ""

    found: dict[str, TechItem] = {}
    for sig in SIGNATURES:
        hits, version = 0, None

        def register(matched: bool, ver: str | None) -> None:
            nonlocal hits, version
            if matched:
                hits += 1
                version = version or ver

        for header, pattern in sig.headers.items():
            if header in headers:
                register(*_match(pattern, headers[header]))
        for pattern in sig.cookies:
            register(any(re.search(pattern, name) for name in cookie_names), None)
        for pattern in sig.html:
            register(*_match(pattern, html))
        for pattern in sig.assets:
            register(*_match(pattern, assets))
        if sig.generator and generator:
            register(*_match(sig.generator, generator))

        if hits:
            # كل دليل إضافي يرفع الثقة في النتيجة
            found[sig.name] = TechItem(name=sig.name, category=sig.category, version=version,
                                       confidence=min(100, 50 + hits * 25))

    # استنتاج التقنيات الضمنية (مثل: Next.js ← React)
    # نستخدم طابوراً لدعم السلاسل (WooCommerce ← WordPress ← PHP)
    queue = list(found)
    while queue:
        for implied in SIGNATURES_BY_NAME[queue.pop()].implies:
            if implied not in found and implied in SIGNATURES_BY_NAME:
                found[implied] = TechItem(name=implied, category=SIGNATURES_BY_NAME[implied].category,
                                          confidence=60)
                queue.append(implied)

    return sorted(found.values(), key=lambda t: (t.category, -t.confidence, t.name))
